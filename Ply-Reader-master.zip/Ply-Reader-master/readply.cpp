#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <GL/glut.h>
#include <pthread.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>

using namespace std;
using namespace glm;

int vListLen;
int fListLen;
glm::vec4 *vList;
int **fList;
glm::vec4 *surfNormList;


//--Traslate--//
glm::mat4 addTransX;
glm::mat4 addTransY;
glm::mat4 addTransZ;
glm::mat4 subTransX;
glm::mat4 subTransY;
glm::mat4 subTransZ;
//--Rotate--//
glm::mat4 rotateXn;
glm::mat4 rotateYn;
glm::mat4 rotateZn;
//--Scale--//
glm::mat4 scaleUp;
glm::mat4 scaleDown;


int readPly(int argc, char *argv[])
{
  FILE *plyFile;
  char line [100];


  //ERROR CHECKING
  //if the user did not enter a file
  if(argc == 1){return -1;}
  plyFile = fopen ( argv[1], "r" );
  //if the fopen failed
  if(!plyFile){return -2;}

  //READS IN VECTORS
  vListLen = atoi(fgets ( line, sizeof line, plyFile ));
  vList = new glm::vec4[vListLen];
  for(int i = 0; i <= vListLen-1; i++)
  {
    float a,b,c;
    fgets ( line, sizeof line, plyFile );
    char *one = strtok (line, " ");
    char *two = strtok (NULL, " ");
    char *three = strtok (NULL, " ");
    vList[i] = glm::vec4( atof(one),
                          atof(two),
                          atof(three),
                          1.0);
    printf("%s\n", glm::to_string(vList[i]).c_str());
  }

  //READS IN FACES
  fListLen = atoi(fgets ( line, sizeof line, plyFile ));
  fList = new int*[fListLen];
  for(int i = 0; i <=fListLen - 1; i++)
  {
    fList[i] = new int[3];
    fgets ( line, sizeof line, plyFile );

    char *trash = strtok (line, " ");
    char *one = strtok (NULL, " ");
    char *two = strtok (NULL, " ");
    char *three = strtok (NULL, " ");

    fList[i][0] = atoi(one);
    fList[i][1] = atoi(two);
    fList[i][2] = atoi(three);
  }
  surfNormList = new glm::vec4[fListLen];
  return 0;
}
int scaleOpenGlUnit()
{
  int xMinMax[2];
  int yMinMax[2];
  int zMinMax[2];
  xMinMax[0] = yMinMax[0] = zMinMax[0] = INT_MIN; //min
  xMinMax[1] = yMinMax[1] = zMinMax[1] = INT_MAX; //max


  for(int i = 0; i <= vListLen-1; i++)
  {
    if(vList[i].x < xMinMax[0])
    {
      xMinMax[0] = vList[i].x;
    }
    if(vList[i].x > xMinMax[1])
    {
      xMinMax[1] = vList[i].x;
    }

    if(vList[i].y < zMinMax[0])
    {
      zMinMax[0] = vList[i].y;
    }
    if(vList[i].y > yMinMax[1])
    {
      yMinMax[1] = vList[i].y;
    }

    if(vList[i].z < zMinMax[0])
    {
      zMinMax[0] = vList[i].z;
    }
    if(vList[i].z > zMinMax[1])
    {
      zMinMax[1] = vList[i].z;
    }

  }
  int xDiv = xMinMax[1] - xMinMax[0];
  int yDiv = yMinMax[1] - yMinMax[0];
  int zDiv = zMinMax[1] - zMinMax[0];

  for(int i = 0; i <= vListLen-1; i++)
   {
     vList[i].x = vList[i].x / xDiv;
     vList[i].y = vList[i].y / yDiv;
     vList[i].z = vList[i].z / zDiv;
     printf("Vector %d |: %f %f %f %f\n", i, vList[i].x, vList[i].y, vList[i].z, vList[i].w);

   }

}

int rotate(char axis)
{
    if('x'==axis)
    {
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=rotateXn*vList[i];
      }
    }
    else if('y'==axis)
    {
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=rotateYn*vList[i];
      }
    }
    else if('z'==axis)
    {
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=rotateZn*vList[i];
      }
    }
}
int trans(char axis, char dir)
{
  if('x'==axis)
  {
    if('-'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=subTransX*vList[i];
      }
    }
    else if('+'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=addTransX*vList[i];
      }
    }
  }
  else if('y'==axis)
  {
    if('-'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=subTransY*vList[i];
      }
    }
    else if('+'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=addTransY*vList[i];
      }
    }
  }
  else if('z'==axis)
  {
    if('-'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=addTransZ*vList[i];
      }
    }
    else if('+'==dir){
      for(int i = 0; i < vListLen; i++)
      {
        vList[i]=subTransZ*vList[i];
      }
    }
  }

}
int scale(char dir)
{
  if('-'==dir){
    for(int i = 0; i < vListLen; i++)
    {
      //printf("Before [%d] --- x: %f y: %f z: %f\n", i, vList[i].x, vList[i].y, vList[i].z);
      vList[i]= scaleDown * vList[i];
      //printf("After [%d] --- x: %f y: %f z: %f\n", i, vList[i].x, vList[i].y, vList[i].z);

    }
  }
  else if('+'==dir){
    for(int i = 0; i < vListLen; i++)
    {
      vList[i]=scaleUp*vList[i];
    }
  }
}

glm::vec4 calcSurfaceNormal(glm::vec4 v1, glm::vec4 v2, glm::vec4 v3)
{
  glm::vec4 tmp;

  tmp.x = (v2.y - v1.y)*(v3.z - v1.z) - (v3.y - v1.y)*(v2.z - v1.z);
  tmp.y = (v2.z - v1.z)*(v3.x - v1.x) - (v2.x - v1.x)*(v3.z - v1.z) ;
  tmp.z = (v2.x - v1.x)*(v3.y - v1.y) - (v3.x - v1.x)*(v2.y - v1.y);
  tmp.w =1;

//printf("%s\n", glm::to_string(tmp).c_str());
  return tmp;
}
float calcDegree(glm::vec4 v1)
{
  glm::vec4 camVec = glm::vec4(0.0, 0.0, 1.0, 1.0);
  float camMag = sqrt(camVec.x*camVec.x + camVec.y*camVec.y + camVec.z*camVec.z);
  float v1Mag = sqrt(v1.x*v1.x + v1.y*v1.y + v1.z*v1.z);
  float dot = camVec.x*v1.x + camVec.y*v1.y + camVec.z*v1.z;
//  puts("==========================");
//  printf("camMag   |: %f\n", camMag);
//  printf("v1Mag   |: %f\n", v1Mag);
//  printf("Dot   |: %f\n", dot);
  float tmp = dot/(v1Mag*camMag);
//  printf("Degree   |: %f\n", tmp);
  return tmp;
}
void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT);


   glBegin(GL_TRIANGLES);
   for(int i = 0; i <= fListLen - 1; i++)
   {
     glm::vec4 sn = calcSurfaceNormal(vList[fList[i][0]], vList[fList[i][1]], vList[fList[i][2]]);
     float d = calcDegree(sn);
     if(d > 0)
     {
       glColor3f(d, 0.0f, 0.0f);
       glVertex3f(vList[fList[i][0]].x, vList[fList[i][0]].y, vList[fList[i][0]].z);
       glColor3f(d, 0.0f, 0.0f);
       glVertex3f(vList[fList[i][1]].x, vList[fList[i][1]].y, vList[fList[i][1]].z);
       glColor3f(d, 0.0f, 0.0f);
       glVertex3f(vList[fList[i][2]].x, vList[fList[i][2]].y, vList[fList[i][2]].z);
      }
    }
   glEnd ();
   glutSwapBuffers();
}
void mloop(int v)
{
  //printf("in mainloop\n");
  display();
  //glutTimerFunc(1000/60, mloop, v);

}
void reshape(int w, int h)
{
  //printf("reshape\n");
}
void keyboard(unsigned char key, int x, int y)
{
  if(key == 'm'){
    while(1){
    rotate('y');
    display();
    usleep(12000);}
  }
  if(key == 'z'){
    scale('-');
    display();
  }
  if(key == 'x'){
    scale('+');
    display();}
  //Rotate
  if(key == 'a'){
    rotate('x');
    display();
  }
  if(key == 's'){
    rotate('y');
    display();}
  if(key == 'd'){
    rotate('z');
    display();}
  //Translate
  if(key == 'q')
  {
    trans('x', '+');
    display();}
  if(key == 'w')
  {
    trans('y', '+');
    display();}
  if(key == 'e')
  {
    trans('z', '+');
    display();}
  if((int)key == 81)
  {
    trans('x', '-');
    display();}
  if((int)key == 87)
  {
    trans('y', '-');
    display();}
  if((int)key == 69)
  {
    trans('z', '-');
    display();}

  /*puts("______AFTER______\n\n");
  for(int i = 0; i < 20; i++)
  {
      printf("vList[%d] -- | x = %f y= %f z = %f |\n",i,vList[i].x, vList[i].y, vList[i].z);
  }
  */
	//printf("keypress: %d    x: %d    y: %d\n", key, x, y);
}
void mouse(int btn, int state, int x, int y)
{
  //printf("button: %d    state: %d    x: %d  y: %d\n", btn, state, x, y);
}
void mouseMotion(int x, int y)
{
  //printf("x: %d  y: %d\n", x, y);
}

void init(void)
{
  //Translate
  float tmp0[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.1,0.0,0.0,1.0
  };addTransX = glm::make_mat4(tmp0);

  float tmp1[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,0.1,0.0,1.0
  };addTransY = glm::make_mat4(tmp1);

  float tmp2[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,0.0,0.1,1.0
  };addTransZ = glm::make_mat4(tmp2);

  float tmp3[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    -0.1,0.0,0.0,1.0
  };subTransX = glm::make_mat4(tmp3);

  float tmp4[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,-0.1,0.0,1.0
  };subTransY = glm::make_mat4(tmp4);

  float tmp5[16] = {
    1.0,0.0,0.0,0.0,
    0.0,1.0,0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,0.0,-0.1,1.0
  };subTransZ = glm::make_mat4(tmp5);

  //Rotate
  float tmp6[16] = {
    1.0,0.0,0.0,0.0,
    0.0,cos(0.1),sin(0.1),0.0,
    0.0,-sin(0.1),cos(0.1),0.0,
    0.0,0.0,0.0,1.0
  };
  rotateXn = glm::make_mat4(tmp6);
  float tmp7[16] = {
    cos(0.1),0.0,-sin(0.1),0.0,
    0.0,1.0,0.0,0.0,
    sin(0.1),0.0,cos(0.1),0.0,
    0.0,0.0,0.0,1.0
  };
  rotateYn = glm::make_mat4(tmp7);
  float tmp8[16] = {
    cos(0.1),sin(0.1),0.0,0.0,
    -sin(0.1),cos(0.1),0.0,0.0,
    0.0,0.0,1.0,0.0,
    0.0,0.0,0.0,1.0
  };
  rotateZn = glm::make_mat4(tmp8);

  //Scale
  float tmp9[16] = {
    1.1,0.0,0.0,0.0,
    0.0,1.1,0.0,0.0,
    0.0,0.0,1.1,0.0,
    0.0,0.0,0.0,1.0
  };
  scaleUp = glm::make_mat4(tmp9);

  float tmp10[16] = {
    0.9,0.0,0.0,0.0,
    0.0,0.9,0.0,0.0,
    0.0,0.0,0.9,0.0,
    0.0,0.0,0.0,1.0
  };
  scaleDown = glm::make_mat4(tmp10);
}
int createWindow(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitWindowSize (1020, 980);
  glutCreateWindow (argv[0]);
  init();
  glutReshapeFunc (reshape);
  glutKeyboardFunc (keyboard);
  glutMouseFunc(mouse);
  glutPassiveMotionFunc(mouseMotion);
  glutTimerFunc(1000/60, mloop, 0); /* 60 == frame rate */
  //glutDisplayFunc (display);
  glutMainLoop();
}



int main (int argc, char *argv[])
{
  int readError = readPly(argc, argv);
  if(readError == -1)
  {
    cout << "plyRead args[0]=filename.ply\n";
    return 0;
  }
  else if(readError == -2)
  {
    cout << "Unable to open file\n";
    return 0;
  }
  scaleOpenGlUnit();
  init();
  scale('-');
  scale('-');
  scale('-');
  scale('-');
  scale('-');
  scale('-');
  trans('y', '+');
  trans('y', '+');
  trans('y', '+');
  trans('y', '+');
  trans('y', '+');
  trans('y', '+');
  trans('z', '-');
  createWindow(argc, argv);

}
