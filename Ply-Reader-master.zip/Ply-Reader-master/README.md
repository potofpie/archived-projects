# Ply Reader

This was a project for my Computer Graphics class.  It reads in a list of vectors and faces then uses openGL to display the object that was stored in the ply file.

## Compling:
To compile use the MakeFile. Go to the directory where the project is stored and type make FILE="readply".

## Running:
To run the project type ./readply monkey.ply. You can read other ply files but they have to have the header removed. See the configuringPly file readme.
