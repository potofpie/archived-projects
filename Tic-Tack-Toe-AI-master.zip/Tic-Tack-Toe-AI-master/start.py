import pygame
from tkinter import *
from tkinter import messagebox
import enum
#import ai

game = []


class Game():
    def __init__(self):
        #gameState
        self.didSelectPlayer = False
        self.didSelectBoard = False
        self.team = False
        self.board = False
        self.state = [SquareStates.NONE,SquareStates.NONE,SquareStates.NONE,SquareStates.NONE,SquareStates.NONE,
                    SquareStates.NONE,SquareStates.NONE,SquareStates.NONE,SquareStates.NONE]

        #window size
        self.width3x3 = 431
        self.height3x3 = 375
        self.width4x4 = 431
        self.height4x4 = 375
        self.spaces3x3 = (20, 15), (157, 15), (300, 15), (20,135), (157,135), (300,135), (20,260), (157,260), (300, 260)
        self.spaces4x4 = (20, 15), (157, 15), (300, 15), (20,135), (157,135), (300,135), (20,260), (157,260), (300, 260)

        #images
        self.board3x3 = pygame.image.load("3x3.png")
        self.board4x4 = pygame.image.load("4x4.png")
        self.x = pygame.image.load("x.png")
        self.o = pygame.image.load("o.png")
        self.smallx = pygame.image.load("smallx.png")
        self.smallo = pygame.image.load("smallo.png")
        self.myfont = pygame.font.SysFont('Comic Sans MS', 70)

        self.gameDisplay = pygame.display.set_mode((self.width3x3, self.height3x3))
        pygame.display.set_caption('Tic Tack Toe')
        self.clock = pygame.time.Clock()
        self.crashed = False

        #init for tkinter aka popup windows
        Tk().wm_withdraw()

class Color(enum.Enum):
    black = (0,0,0)
    white = (255,255,255)
    red = (255,0,0)
    green = (0,255,0)
    blue = (0,0,255)

class SquareStates(enum.Enum):
    X = 1
    O = 2
    NONE = 3


def move(x, y, image, t):
    global game
    if x > 20 and x < 120 and y > 15 and y < 115:
        if game.state[0] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[0])
            game.state[0] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    if x > 157 and x < 270 and y > 15 and y < 115:
        if game.state[1] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[1])
            game.state[1] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    if x > 300 and x < 407 and y > 15 and y < 115:
        if  game.state[2] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[2])
            game.state[2] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    elif x > 20 and x < 120 and y > 135 and y < 235:
        if game.state[3] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[3])
            game.state[3] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    elif x > 157 and x < 270 and y > 135 and y < 235:
        if game.state[4] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[4])
            game.state[4] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    elif x > 300 and x < 407 and y > 135 and y < 235:
        if game.state[5] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[5])
            game.state[5] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')

    elif x > 20 and x < 120 and y > 260 and y < 360:
        if game.state[6] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[6])
            game.state[6] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    elif x > 157 and x < 270 and y > 260 and y < 360:
        if game.state[7] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[7])
            game.state[7] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    elif x > 300 and x < 407 and y > 260 and y < 360:
        if game.state[8] is SquareStates.NONE:
            game.gameDisplay.blit(image, game.spaces3x3[8])
            game.state[8] = t
        else:
            messagebox.showinfo('Space is taken!','Space is taken!')
    pygame.display.update()

def gameScreen4():
    global game
    game.gameDisplay.fill((255,255,255))
    game.gameDisplay.blit(game.board4x4, (0,0))


def gameScreen3():
    global game
    game.gameDisplay.fill((255,255,255))
    game.gameDisplay.blit(game.board3x3, (0,0))
    while not game.crashed:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                (x, y) = pygame.mouse.get_pos()
                if game.team is SquareStates.O:
                    move(x,y,game.o,SquareStates.O)
                elif game.team is SquareStates.X:
                    move(x,y,game.x,SquareStates.X)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    game.gameDisplay.fill((255,255,255))

            if event.type == pygame.QUIT:
                game.crashed = True


            game.clock.tick(60)



def pickBoardScreen():
    global game
    game.gameDisplay.fill((255,255,255))
    pickBoardText = game.myfont.render('Pick your board!', False, (0, 0, 0))
    b3x3Text = game.myfont.render('3x3', False, (0, 0, 0))
    b4x4Text = game.myfont.render('4x4', False, (0, 0, 0))
    game.gameDisplay.blit(pickBoardText, (25,75))
    game.gameDisplay.blit(b3x3Text, (250,150))
    game.gameDisplay.blit(b4x4Text, (100,150))
    pygame.display.update()
    while(game.board is False):
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                (x, y) = pygame.mouse.get_pos()
                #print((x,y))
                if x > 101 and x < 195 and y > 148 and y < 245:
                    game.board = 4
                if x > 249 and x < 337 and y > 149 and y < 250:
                    game.board = 3
        pass
def pickXorOScreen():
    global game
    game.gameDisplay.fill((255,255,255))
    game.gameDisplay.blit(game.o, (250,150))
    game.gameDisplay.blit(game.x, (100,150))
    pickTeamText = game.myfont.render('Pick X or O!', False, (0, 0, 0))
    game.gameDisplay.blit(pickTeamText, (75,75))
    pygame.display.update()
    while(game.team is False):
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                (x, y) = pygame.mouse.get_pos()
                #print((x,y))
                if x > 101 and x < 195 and y > 148 and y < 245:
                    game.team = SquareStates.X

                if x > 249 and x < 337 and y > 149 and y < 250:
                    game.team = SquareStates.O
        pass
    game.gameDisplay.fill((255,255,255))


def main():
    global game
    pygame.init()
    game = Game()


    pickBoardScreen()
    pickXorOScreen()
    if(game.board is 3):
        gameScreen3()
    elif(game.board is 4):
        gameScreen4()

    while not game.crashed:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    game.gameDisplay.fill((255,255,255))
            if event.type == pygame.QUIT:
                game.crashed = True
            pygame.display.update()
            game.clock.tick(60)

    pygame.quit()
    quit()



if __name__== "__main__":
  main()
