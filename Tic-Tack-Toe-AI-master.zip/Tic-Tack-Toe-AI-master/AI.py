from Board import Board
from math import inf as infinity
import copy
import sys

from INFO import INFO
class AI():
    def __init__(self, board):
        #print("init AI")
        self.board = board

    def calcLine(self, player, comp):
        if(self.board.boardSize is INFO.B3x3):
            if player is 0 and comp is 3:
                return 100
            elif player is 0 and comp is 2:
                return 80
            elif player is 0 and comp is 1:
                return 70
            elif player is 0 and comp is 0:
                return 60
            elif player is 1 and comp is 2:
                return 30
            elif player is 1 and comp is 1:
                return 30
            elif player is 1 and comp is 0:
                return 20
            elif player is 2 and comp is 1:
                return 90
            elif player is 2 and comp is 0:
                return 10
            elif player is 3 and comp is 0:
                return 0
            else:
                return 2
                print("ELSE || " + str(player) + str(comp))

        if(self.board.boardSize is INFO.B4x4):
            if player is 0 and comp is 4:
                return 100
            if player is 0 and comp is 3:
                return 99
            elif player is 0 and comp is 2:
                return 70
            elif player is 0 and comp is 1:
                return 60
            elif player is 0 and comp is 0:
                return 50
            elif player is 1 and comp is 3:
                return 5
            elif player is 1 and comp is 2:
                return 20
            elif player is 1 and comp is 1:
                return 20
            elif player is 1 and comp is 0:
                return 15
            elif player is 2 and comp is 2:
                return 20
            elif player is 2 and comp is 1:
                return 20
            elif player is 2 and comp is 0:
                return 30
            elif player is 3 and comp is 1:
                return  90
            elif player is 3 and comp is 0:
                return 10
            elif player is 4 and comp is 0:
                return 0
            else:
                return 2
                print("ELSE || " + str(player) + str(comp))

    def evalu(self, state):
      score = 0
      rowC = 0
      comp = 0
      player = 0
      if(self.board.boardSize is INFO.B3x3):
          for i in state:
              rowC = rowC + 1
              if i is self.board.compTeam:
                  comp = comp + 1
              if i is self.board.playerTeam:
                  player = player + 1
              if rowC is 3 :
                  score = score + self.calcLine(player, comp)

          comp = 0
          player = 0
          for i in range(0,3):
              for j in range(0,3):
                x = i + (j * 3)
                if state[x] is self.board.compTeam:
                    comp = comp + 1
                if state[x] is self.board.playerTeam:
                    player = player + 1
              score = score + self.calcLine(player, comp)

          backSlash = [state[2], state[4], state[6]]
          comp = 0
          player = 0
          for i in backSlash:
                if i is self.board.compTeam:
                    comp += 1
                if i is self.board.playerTeam:
                    player += 1
          score = score + self.calcLine(player, comp)


          forwardSlash = [state[0], state[4], state[8]]
          comp = 0
          player = 0
          for i in backSlash:
                if i is self.board.compTeam:
                    comp += 1
                if i is self.board.playerTeam:
                    player += 1
          score = score + self.calcLine(player, comp)

      if(self.board.boardSize is INFO.B4x4):
           for i in state:
               rowC = rowC + 1
               if i is self.board.compTeam:
                   comp = comp + 1
               if i is self.board.playerTeam:
                   player = player + 1
               if rowC is 4 :
                   score = score + self.calcLine(player, comp)

           comp = 0
           player = 0
           for i in range(0,4):
               for j in range(0,4):
                 x = i + (j * 4)
                 if state[x] is self.board.compTeam:
                     comp = comp + 1
                 if state[x] is self.board.playerTeam:
                     player = player + 1
               score = score + self.calcLine(player, comp)

           backSlash = [state[3], state[6], state[9], state[12]]
           comp = 0
           player = 0
           for i in backSlash:
                 if i is self.board.compTeam:
                     comp += 1
                 if i is self.board.playerTeam:
                     player += 1
           score = score + self.calcLine(player, comp)


           forwardSlash = [state[0], state[5], state[10], state[15]]
           comp = 0
           player = 0
           for i in backSlash:
                 if i is self.board.compTeam:
                     comp += 1
                 if i is self.board.playerTeam:
                     player += 1
           score = score + self.calcLine(player, comp)
      return score


    def printState(self, state):
        if self.board.boardSize is INFO.B3x3:
            lineSize = 2
        elif self.board.boardSize is INFO.B4x4:
            lineSize = 3

        for i in range(0,lineSize + 1):

            for j in range(0,lineSize + 1):

                print( " " + str(state[j + (lineSize * i)]) + " ", end = '', flush = True)
            print()

    def minimax(self, s, player, depth):
            thing = 0
            print("=====| Player: " + str(player) + " |=====| Depth: " + str(depth) + " |=====| Score: " + str(self.evalu(s)) + " |=====")
            self.printState(s)
            #max
            if player == self.board.compTeam:
                best = [-1, -infinity]
            #min
            else:
                best = [-1, +infinity]

            if depth is 0 or self.board.checkState(s) is not INFO.CONTINUE:
                return [0, self.evalu(s)]
            if(self.board.boardSize is INFO.B4x4):
                thing = 16
            else:
                thing = 9
            for space in range(0,thing):
                if s[space] is INFO.NONE:
                    score = [space, 0]
                    if player is self.board.compTeam:
                        tmpState = copy.copy(s)
                        tmpState[space] = player
                        score[1] = self.minimax(tmpState, self.board.playerTeam, depth - 1)[1]
                    else:
                        tmpState = copy.copy(s)
                        tmpState[space] = player
                        score[1] = self.minimax(tmpState, self.board.compTeam, depth - 1)[1]

                    if player is self.board.compTeam:
                        if score[1] > best[1] and self.board.state[score[0]] is INFO.NONE:
                            best[0] = space  # max value
                    else:
                        if score[1] < best[1] and self.board.state[score[0]] is INFO.NONE:
                            best[0] = space  # min value
            return best

    def getCollumn2(self):
        if(index is 0):
            return [ self.board.getState()[3], self.board.getState()[6]]
        if(index is 1):
            return [ self.board.getState()[4], self.board.getState()[7]]
        if(index is 2):
            return [ self.board.getState()[5], self.board.getState()[8]]
        elif(index is 3):
            return [self.board.getState()[0],  self.board.getState()[6]]
        elif(index is 4):
            return [self.board.getState()[1],  self.board.getState()[7]]
        elif(index is 5):
            return [self.board.getState()[2],  self.board.getState()[8]]
        elif(index is 6):
            return [self.board.getState()[0], self.board.getState()[3]]
        elif(index is 7):
            return [self.board.getState()[1], self.board.getState()[4]]
        elif(index is 8):
            return [self.board.getState()[2], self.board.getState()[5]]

    def eval2(self):
        scores = [-100, -100, -100,
                  -100, -100, -100,
                  -100, -100, -100]
        for i in range(0,9):
            if self.board.getState()[i] is INFO.NONE:
                scoringItems = []
                score = 0
                try:
                    scoringItems.extend(self.getSlash2(i))
                except:
                    pass
                scoringItems.extend(self.getRow2(i))
                scoringItems.extend(self.getCollumn2(i))
                for j in scoringItems:
                    if j is INFO.NONE:
                        score +=1
                    elif j is self.board.compTeam:
                        score +=2
                    elif j is self.board.playerTeam:
                        score -=2
                #print("-----Move " + str(i) +"-----")
                #print(score)
                scores[i] = score
        bestMove = 0
        for i in range(0,9):
            if scores[i] > scores[bestMove]:
                bestMove = i
        #print("-----bestMove-----")
        #print(bestMove)
        return bestMove



    def getSlash2(self, index):

        if(index is 0):
            return [self.board.getState()[4], self.board.getState()[8]]
        elif(index is 2):
            return [self.board.getState()[4], self.board.getState()[6]]
        elif(index is 4):
            return [self.board.getState()[0], self.board.getState()[8],self.board.getState()[6], self.board.getState()[2]]
        elif(index is 6):
            return [self.board.getState()[2], self.board.getState()[4]]
        elif(index is 8):
            return [self.board.getState()[2], self.board.getState()[4]]

    def getRow2(self, index):
        if(index is 0):
            return [ self.board.getState()[1], self.board.getState()[2]]
        elif(index is 1):
            return [self.board.getState()[0], self.board.getState()[2]]
        elif(index is 2):
            return [self.board.getState()[0], self.board.getState()[1]]
        elif(index is 3):
            return [self.board.getState()[3], self.board.getState()[4]]
        elif(index is 4):
            return [self.board.getState()[3],  self.board.getState()[4]]
        elif(index is 5):
            return [self.board.getState()[3], self.board.getState()[4]]
        elif(index is 6):
            return [self.board.getState()[7], self.board.getState()[8]]
        elif(index is 7):
            return [self.board.getState()[6], self.board.getState()[8]]
        elif(index is 8):
            return [self.board.getState()[6], self.board.getState()[7]]

    def getCollumn2(self, index):
        if(index is 0):
            return [ self.board.getState()[3], self.board.getState()[6]]
        if(index is 1):
            return [ self.board.getState()[4], self.board.getState()[7]]
        if(index is 2):
            return [ self.board.getState()[5], self.board.getState()[8]]
        elif(index is 3):
            return [self.board.getState()[0],  self.board.getState()[6]]
        elif(index is 4):
            return [self.board.getState()[1],  self.board.getState()[7]]
        elif(index is 5):
            return [self.board.getState()[2],  self.board.getState()[8]]
        elif(index is 6):
            return [self.board.getState()[0], self.board.getState()[3]]
        elif(index is 7):
            return [self.board.getState()[1], self.board.getState()[4]]
        elif(index is 8):
            return [self.board.getState()[2], self.board.getState()[5]]
