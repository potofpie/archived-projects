from INFO import INFO

def checkState(state):
      #check rows
          rowC = 0
          xC = 0
          oC = 0
          for i in state:
              rowC = rowC + 1
              if i is INFO.X:
                  xC = xC + 1
              if i is INFO.O:
                  oC = oC + 1
              if rowC is 3 :
                  if xC is 3:
                      return INFO.XWIN
                  elif oC is 3:
                      return INFO.OWIN
                  else:
                      rowC = 0
                      xC = 0
                      oC = 0

      #check columns
          columnC = 0
          xC = 0
          oC = 0
          for i in range(0,3):
              for j in range(0,3):
                  x = i + (j * 3)
                  if state[x] is INFO.X:
                      xC = xC + 1
                  if state[x] is INFO.O:
                      oC = oC + 1
              if xC is 3:
                  return INFO.XWIN
              elif oC is 3:
                  return INFO.OWIN
              else:
                  xC = 0
                  oC = 0
          #check backSlash
          if state[2] is INFO.X and state[4] is INFO.X and state[6] is INFO.X:
              return INFO.XWIN

          if state[2] is INFO.O and state[4] is INFO.O and state[6] is INFO.O:
              return INFO.OWIN

          #check forwardSlash
          if state[0] is INFO.X and state[4] is INFO.X and state[8] is INFO.X:
              return INFO.XWIN

          if state[0] is INFO.O and state[4] is INFO.O and state[8] is INFO.O:
              return INFO.OWIN

          C = 0
          for space in state:
              if space is not INFO.NONE:
                  C = C + 1
          if C is 8:
              return INFO.TIE
          else:
              return INFO.CONTINUE

state = [INFO.X,INFO.NONE,INFO.NONE,
         INFO.NONE,INFO.O,INFO.NONE,
         INFO.NONE,INFO.NONE,INFO.X]
print(checkState(state))
