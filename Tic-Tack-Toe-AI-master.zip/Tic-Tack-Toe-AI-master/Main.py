from Board import Board
from GUI import GUI
from AI import AI
from INFO import INFO
import time

board = Board()
ai = AI(board)
gui = GUI(board, ai)


while(True):
    gui.startScreen()
    gui.pickBoardScreen()
    gui.pickTeamScreen()
    gui.gameScreen()
    board.__init__()
