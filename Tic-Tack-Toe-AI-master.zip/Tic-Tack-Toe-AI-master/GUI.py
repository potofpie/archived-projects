from INFO import INFO
from AI import AI
import pygame
from tkinter import *
from tkinter import messagebox
from Board import Board
import os
import time
import copy

class GUI():
    def __init__(self, board, ai):

        self.centerWindow()
        #print("init GUI")

        pygame.init()

        self.ai = ai
        self.board = board
        #window size
        self.width = 431
        self.height = 375

        #pygame stuff
        self.gameDisplay = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption('Tic Tack Toe')
        self.clock = pygame.time.Clock()

        #space info
        self.spaces3x3 = (
                          ((20, 15),(120,115)), ((157, 15),(270,115)), ((300, 15),(407,115)),
                          ((20,135),(120,235)), ((157,135),(270,235)), ((300,135),(407,235)),
                          ((20,260),(120,360)), ((157,260),(270,360)), ((300, 260),(407,360))
                         )
        self.spaces4x4 = (
                          ((15, 10),(77, 80)), ((103, 10),(199, 80)), ((224, 10),(314, 80)), ((342, 10),(415, 80)),
                          ((15, 106),(81, 180)), ((104, 102),(202, 180)), ((222, 100),(318, 182)), ((340, 102),(414, 176)),
                          ((10, 207),(82, 276)), ((110, 208),(200, 275)), ((229, 210),(320, 276)), ((342, 208),(410, 272)),
                          ((12, 301),(78, 361)), ((108, 302),(195, 356)), ((230, 303),(322, 361)), ((350, 307),(419, 361)),
                         )



        #images
        self.board3x3 = pygame.image.load("3x3.png")
        self.board4x4 = pygame.image.load("4x4.png")
        self.x = pygame.image.load("x.png")
        self.o = pygame.image.load("o.png")
        self.smallx = pygame.image.load("smallx.png")
        self.smallo = pygame.image.load("smallo.png")
        self.startbutton = pygame.image.load("Start Button.png")
        self.myfont = pygame.font.SysFont('Comic Sans MS', 70)

        self.title = self.myfont.render('Tic Tack Toe!', False, (0, 0, 0))
        self.pickBoardText = self.myfont.render('Pick your board!', False, (0, 0, 0))
        self.pickTeamText = self.myfont.render('Pick you team!', False, (0, 0, 0))
        self.xWon = self.myfont.render('X Won!', False, (0, 0, 0))
        self.oWon = self.myfont.render('O Won!', False, (0, 0, 0))
        self.tie = self.myfont.render('Tie!', False, (0, 0, 0))

        self.b3x3Text = self.myfont.render('3x3', False, (0, 0, 0))
        self.b4x4Text = self.myfont.render('4x4', False, (0, 0, 0))


    def makeMove(self, space, team):
        if space is not None:
            if self.board.boardSize is INFO.B3x3:
                if team is INFO.X:
                    image = self.x
                else:
                    image = self.o

                if self.board.state[space] is INFO.NONE:
                    self.gameDisplay.blit(image, self.spaces3x3[space][0])
                    self.board.state[space] = team
                else:
                    messagebox.showinfo('Space is taken!','Space is taken!')

            if self.board.boardSize is INFO.B4x4:
                if team is INFO.X:
                    image = self.smallx
                else:
                    image = self.smallo

                if self.board.state[space] is INFO.NONE:
                    if space is 5 or space is 6:
                        (x,y) = self.spaces4x4[space][0]
                        self.gameDisplay.blit(image, (x+10,y+10))
                    else:
                        self.gameDisplay.blit(image, self.spaces4x4[space][0])
                    self.board.state[space] = team
                else:
                    messagebox.showinfo('Space is taken!','Space is taken!')
            self.board.playersTurn = False
            pygame.display.update()



    def getClick(self):
        while self.board.playersTurn:
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONUP:
                    (x, y) = pygame.mouse.get_pos()
                    for i in range(0,9):
                        if x > self.spaces3x3[i][0][0] and x < self.spaces3x3[i][1][0] and y > self.spaces3x3[i][0][1] and y < self.spaces3x3[i][1][1]:
                            return i
                        elif self.board.boardSize is INFO.B4x4:
                            for i in range(0,16):
                                if x > self.spaces4x4[i][0][0] and x < self.spaces4x4[i][1][0] and y > self.spaces4x4[i][0][1] and y < self.spaces4x4[i][1][1]:
                                    return i


            self.clock.tick(60)
        self.board.playersTurn = False


    def startScreen(self):
        self.gameDisplay.fill((255,255,255))
        self.gameDisplay.blit(self.title, (70,100))
        self.gameDisplay.blit(self.startbutton, (100,200))
        pygame.display.update()
        while(True):
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONUP:
                    (x, y) = pygame.mouse.get_pos()
                    print (x,y)
                    if x > 100 and x < 320 and y > 200 and y < 265:
                        return

    def winScreen(self,winner):
        self.gameDisplay.fill((255,255,255))
        print(winner)
        if(winner is INFO.XWIN):
            self.gameDisplay.blit(self.xWon, (130,100))
        elif(winner is INFO.OWIN):
            self.gameDisplay.blit(self.oWon, (130,100))
        elif(winner is INFO.TIE):
            self.gameDisplay.blit(self.tie, (130,100))
        else:
            return
        pygame.display.update()
        time.sleep(3)

    def gameScreen(self):
        if(self.board.getBoardSize() is INFO.B3x3 ):
            self.gameDisplay.fill((255,255,255))
            self.gameDisplay.blit(self.board3x3, (0,0))
        elif(self.board.getBoardSize() is INFO.B4x4 ):
            self.gameDisplay.fill((255,255,255))
            self.gameDisplay.blit(self.board4x4, (0,0))
        pygame.display.update()

        while(True):
            if self.board.checkState(self.board.state) is INFO.CONTINUE:
                self.makeMove(self.getClick(), self.board.playerTeam)
            else:
                break
            if self.board.checkState(self.board.state) is INFO.CONTINUE:
                s = copy.copy(self.board.state)
                print("========================| MOVE |=========================")
                b = self.ai.minimax(s, self.board.compTeam, 4)[0]
                self.makeMove(b, self.board.compTeam)
                self.board.playersTurn = True
            else:
                break
        self.winScreen(self.board.checkState(self.board.state))


    def pickBoardScreen(self):
        self.gameDisplay.fill((255,255,255))
        self.gameDisplay.blit(self.pickBoardText, (25,75))
        self.gameDisplay.blit(self.b3x3Text, (250,150))
        self.gameDisplay.blit(self.b4x4Text, (100,150))
        pygame.display.update()
        while(self.board.getBoardSize() is INFO.NONE):
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONUP:
                    (x, y) = pygame.mouse.get_pos()
                    #print((x,y))
                    if x > 101 and x < 195 and y > 148 and y < 245:
                        self.board.setBoardSize(INFO.B4x4)
                    if x > 249 and x < 337 and y > 149 and y < 250:
                        self.board.setBoardSize(INFO.B3x3)
            pass
        print(self.board.getBoardSize())


    def pickTeamScreen(self):
        self.gameDisplay.fill((255,255,255))
        self.gameDisplay.blit(self.pickBoardText, (25,75))
        self.gameDisplay.blit(self.x, (250,150))
        self.gameDisplay.blit(self.o, (100,150))
        pygame.display.update()
        while(self.board.getPlayerTeam() is INFO.NONE):
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONUP:
                    (x, y) = pygame.mouse.get_pos()
                    if x > 101 and x < 195 and y > 148 and y < 245:
                        self.board.setPlayerTeam(INFO.O)
                        self.board.compTeam = INFO.X
                    if x > 249 and x < 337 and y > 149 and y < 250:
                        self.board.setPlayerTeam(INFO.X)
                        self.board.compTeam = INFO.O

            pass
        print("playerteam " + str(self.board.getPlayerTeam()))
        print("compTeam " + str(self.board.compTeam))

        self.gameDisplay.fill((255,255,255))
    def centerWindow(self):
        root = Tk()
        root.wm_withdraw()

        windowWidth = root.winfo_reqwidth()
        windowHeight = root.winfo_reqheight()

        positionRight = int(root.winfo_screenwidth()/2 - windowWidth/2)
        positionDown = int(root.winfo_screenheight()/2 - windowHeight/2)
        os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (positionRight-100,positionDown-100)
