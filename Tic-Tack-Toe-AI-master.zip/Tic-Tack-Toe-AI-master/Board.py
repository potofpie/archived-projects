from INFO import INFO


class Board():
    def __init__(self):
        #print("init Board")
        self.boardSize = INFO.NONE
        self.playerTeam = INFO.NONE
        self.compTeam = INFO.NONE
        self.state = INFO.NONE
        self.playersTurn = True

    def checkState(self, state):
        #check rows
        if(self.boardSize is INFO.B3x3):
            rowC = 0
            xC = 0
            oC = 0
            for i in state:
                rowC = rowC + 1
                if i is INFO.X:
                    xC = xC + 1
                if i is INFO.O:
                    oC = oC + 1
                if rowC is 3 :
                    if xC is 3:
                        return INFO.XWIN
                    elif oC is 3:
                        return INFO.OWIN
                    else:
                        rowC = 0
                        xC = 0
                        oC = 0

        #check columns
            columnC = 0
            xC = 0
            oC = 0
            for i in range(0,3):
                for j in range(0,3):
                    x = i + (j * 3)
                    if state[x] is INFO.X:
                        xC = xC + 1
                    if state[x] is INFO.O:
                        oC = oC + 1
                if xC is 3:
                    return INFO.XWIN
                elif oC is 3:
                    return INFO.OWIN
                else:
                    xC = 0
                    oC = 0
            #check backSlash
            if state[2] is INFO.X and state[4] is INFO.X and state[6] is INFO.X:
                return INFO.XWIN

            if state[2] is INFO.O and state[4] is INFO.O and state[6] is INFO.O:
                return INFO.OWIN

            #check forwardSlash
            if state[0] is INFO.X and state[4] is INFO.X and state[8] is INFO.X:
                return INFO.XWIN

            if state[0] is INFO.O and state[4] is INFO.O and state[8] is INFO.O:
                return INFO.OWIN

            C = 0
            for space in state:
                if space is not INFO.NONE:
                    C = C + 1
            if C is 9:
                return INFO.TIE
            else:
                return INFO.CONTINUE

        elif(self.boardSize is INFO.B4x4):

            #check rows
            rowC = 0
            xC = 0
            oC = 0
            for i in state:
                rowC = rowC + 1
                if i is INFO.X:
                    xC = xC + 1
                if i is INFO.O:
                    oC = oC + 1
                if rowC is 4 :
                    if xC is 4:
                        return INFO.XWIN
                    elif oC is 4:
                        return INFO.OWIN
                    else:
                        rowC = 0
                        xC = 0
                        oC = 0

            #check columns
            columnC = 0
            xC = 0
            oC = 0
            for i in range(0,4):
                for j in range(0,4):
                    x = i + (j * 4)
                    if state[x] is INFO.X:
                        xC = xC + 1
                    if state[x] is INFO.O:
                        oC = oC + 1
                if xC is 4:
                    return INFO.XWIN
                elif oC is 4:
                    return INFO.OWIN
                else:
                    xC = 0
                    oC = 0

            #check backSlash
            if state[3] is INFO.X and state[6] is INFO.X and state[9] is INFO.X and state[12] is INFO.X:
                return INFO.XWIN

            if state[3] is INFO.O and state[6] is INFO.O and state[9] is INFO.O and state[12] is INFO.O:
                return INFO.OWIN

            #check forwardSlash
            if state[0] is INFO.X and state[5] is INFO.X and state[10] is INFO.X and state[15] is INFO.X:
                return INFO.XWIN

            if state[0] is INFO.X and state[5] is INFO.O and state[10] is INFO.O and state[15] is INFO.O:
                return INFO.OWIN

            C = 0
            for space in state:
                if space is not INFO.NONE:
                    C = C + 1
            if C is 16:
                return INFO.TIE
            else:
                return INFO.CONTINUE

    def move(self, space, team):
        self.state[space] = team

    def getState(self):
        return self.state

    def getBoardSize(self):
        return self.boardSize

    def getPlayerTeam(self):
        return self.playerTeam

    def setBoardSize(self, tmpBoardSize):
        self.boardSize = tmpBoardSize
        if self.boardSize is INFO.B3x3:
            self.state = [INFO.NONE,INFO.NONE,INFO.NONE,
                          INFO.NONE,INFO.NONE,INFO.NONE,
                          INFO.NONE,INFO.NONE,INFO.NONE]
        if self.boardSize is INFO.B4x4:
            self.state = [INFO.NONE,INFO.NONE,INFO.NONE,INFO.NONE,
                          INFO.NONE,INFO.NONE,INFO.NONE,INFO.NONE,
                          INFO.NONE,INFO.NONE,INFO.NONE,INFO.NONE,
                          INFO.NONE,INFO.NONE,INFO.NONE,INFO.NONE]


    def setPlayerTeam(self, tmpPlayerTeam):
        self.playerTeam = tmpPlayerTeam

        if(self.playerTeam is INFO.X):
            self.compTeam = INFO.O
        if(self.playerTeam is INFO.O):
            self.compTeam = INFO.X
