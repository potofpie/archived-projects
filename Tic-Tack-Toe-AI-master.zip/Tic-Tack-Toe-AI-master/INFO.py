import enum

class INFO(enum.IntEnum):
    X = 1
    O = 2
    NONE = -100
    B3x3 = 4
    B4x4 = 5
    XWIN = 6
    OWIN = 7
    TIE = 8
    CONTINUE = 9
    SELF = 10
