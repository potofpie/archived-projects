# Tic-Tack-Toe-AI

This is a project for my artificial intelligence class. I am using the MinMax algorithm with Alpha Beta pruning. Hope you enjoy!


## Run info
python Main.py
