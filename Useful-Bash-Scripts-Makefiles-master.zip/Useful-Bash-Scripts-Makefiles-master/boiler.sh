#! /bin/bash
function main() {
  if [ -z ${args[0]} ]
  then
    echo "basher.sh| arg0:lang arg1:(filename)"
  else
    validLang
  fi
}

#Add language here when making adding a template to the system
function validLang() {
  if [ "java" == "${args[0]}" ]
  then
    java
  elif [ "python" == "${args[0]}" ]
  then
    python
  elif [ "c" == "${args[0]}" ]
  then
    c
  elif [ "react" == "${args[0]}" ]
  then
    react
  elif [ "bash" == "${args[0]}" ]
  then
    bash
  else
    echo "${args[0]} is not an option: react, c, python, java, bash"
    exit
  fi
}

function react() {
  if [ -z ${args[1]} ]
  then
    cp -a $path/HelloWorld.js ./
  else
    cp -a $path/HelloWorld.js ./${args[1]}.js
    echo "the thing is not set"
  fi
}

function java() {
  if [ -z ${args[1]} ]
  then
    cp -a $path/HelloWorld.java ./
  else
    cp -a $path/HelloWorld.java ./${args[1]}.java
    grep -rl HelloWorld ./${args[1]}.java | xargs sed -i "s/HelloWorld/${args[1]}/g"
  fi
}

function c() {
  if [ -z ${args[1]} ]
  then
    cp -a $path/HelloWorld.c ./

  else
    cp -a $path/HelloWorld.c ./${args[1]}.c
  fi
}

function python() {
  if [ -z ${args[1]} ]
  then
    cp -a $path/HelloWorld.py ./
  else
    cp -a $path/HelloWorld.py ./${args[1]}.py
  fi
}

function bash() {
  if [ -z ${args[1]} ]
  then
    cp -a $path/HelloWorld.py ./
  else
    cp -a $path/HelloWorld.py ./${args[1]}.sh
  fi
}

#add alias boiler='/home/bob/Dropbox/Shell_Makefiles/boiler.sh' to .bashrc
###START###
path="/home/bob/Dropbox/Templates"
args=("$@")
main
