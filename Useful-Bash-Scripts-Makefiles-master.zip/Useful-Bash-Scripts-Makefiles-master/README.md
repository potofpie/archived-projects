# Useful-Bash-Scripts-Makefiles
These are some of the useful bash scripts and make files I have created to boost my productivity. 

boiler.sh - used to create templates for a couple of frequently used languages.
