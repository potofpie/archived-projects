


import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  appBar:{
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2B2D42',
  },
  logo: {
    flex: 1,
    height: '90%',
  }
});