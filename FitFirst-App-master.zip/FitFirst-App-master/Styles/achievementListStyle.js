import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    padding: 20,
    marginBottom: 10,
    backgroundColor: '#fffffd'
},
    textContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  achievementContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    marginTop: 5,
    marginRight: 5,
    justifyContent: 'center',
    alignItems: 'center',

  },
  picture: {
    width: 50, 
    height: 50,
  },
  statText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 24,
    color: '#BF4342',

  },
  unitText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 9,
    color: '#BF4342',
  },
  desText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 10,
    color: '#EDFFFC'
  },
});