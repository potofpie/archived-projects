import tmpPic from '../Resources/tom.jpg';
import {Fonts} from '../Resources/untils';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({

  nameText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 24,
    color: '#2B2D42', 
  },
  gymText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 10,
    color: '#2B2D42', 
  },
  usernameText:{
    fontFamily: 'Montserrat-Regular',
    fontSize: 10,
    color: '#2B2D42', 
  },
  header: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    textAlignVertical: 'center',
    paddingBottom: 5,
    paddingTop: 10,

},
  picture: {
    flex: 1,
    width: '100%', 
    height: '100%', 
  },
  pictureContainer:{
    width: 125, 
    height: 125,
    borderColor: '#2B2D42',
    borderRadius: 100, 
    borderWidth: 3,     
    justifyContent: 'center',
    alignItems: 'center', 
    overflow: 'hidden',
    elevation: 5,
  },
  left:{
    flex:3, 
    justifyContent:'center', 
    alignItems:'center',
    padding: 10,
    
   
  },
  flexRow: {
    flex: 1,
    flexDirection: 'row',
  },
  right:{
    flex:2, 
    justifyContent: 'center',
    
  },
});