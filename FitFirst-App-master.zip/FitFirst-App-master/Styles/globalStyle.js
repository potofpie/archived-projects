


import { StyleSheet, Dimensions } from 'react-native';


let screenHeight = Dimensions.get('window').height;
let screenWidth = Dimensions.get('window').width;


export default StyleSheet.create({
  pageContainer: {
    flex: 1,
    width: screenWidth,
    height: screenHeight - 24,
    flexDirection: 'column',
    justifyContent: 'center', 
    alignItems: 'flex-start',
    elevation: 5,
    
  },
  backgroundGrey: {
    backgroundColor: '#2B2D42', 
  },
  backgroundWhite: {
    backgroundColor: '#EDFFFC', 
  }
});