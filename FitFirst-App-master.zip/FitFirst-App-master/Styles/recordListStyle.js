import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    records: {
      flex: 1,
      flexDirection: 'row', 
      backgroundColor: '#2B2D42', 
      margin: 15, 
      elevation: 5
},
    line:{
      flex: 1, 
      backgroundColor: '#EDFFFC',  
      marginBottom: 10, 
      marginTop: 10
    },
    statText:{
      fontFamily: 'Montserrat-Regular',
      fontSize: 24,
      color: '#BF4342',

    },
    unitText:{
      fontFamily: 'Montserrat-Regular',
      fontSize: 9,
      color: '#BF4342',
    },
    desText:{
      fontFamily: 'Montserrat-Regular',
      fontSize: 10,
      color: '#EDFFFC'
    },
    usernameText:{
      fontFamily: 'Montserrat-Regular',
      fontSize: 10,
    },

});