//Components
import React, {Component} from 'react';
import {View, Image,Text } from 'react-native';
import ElevatedView from 'react-native-elevated-view';

//Styles
import globalStyle from '../Styles/globalStyle';

import logo from '../Resources/logo_transparent.png'
import appBarStyles from '../Styles/appBarStyles'
//<Image style={appBarStyles.logo} source={logo}/>

export default class Profile extends Component{
  render() {
    return (
          
            <ElevatedView elevation={10} style={appBarStyles.appBar}>
                <Image style={appBarStyles.logo}source={logo} resizeMode='contain'></Image>
            </ElevatedView>
          
         

    );
  }
}

