//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, ScrollView, Dimensions, Image,TouchableWithoutFeedback} from 'react-native';
import ProfileHeader from './ProfileHeader.js';
import Records from './RecordList/RecordList.js';
import AchievementList from './AchievementList/AchievementList.js';
import AppBar from '../AppBar'
import ElevatedView from 'react-native-elevated-view';

//Styles
import globalStyle from '../../Styles/globalStyle';
import profileStyles from '../../Styles/appBarStyles'

import tmppic from '../../Resources/logo_transparent.png'


export default class Profile extends Component{
  render() {
    let screenHeight = Dimensions.get('window').height;
    let screenWidth = Dimensions.get('window').width;
    var size = { 
      x: 0,
      y: 0,
      height: 67,
      width: screenWidth - 30

    }
    return (
      
        <View style={[globalStyle.pageContainer, globalStyle.backgroundWhite]}>
            <AppBar/>
              <View style={{flex: 10,  width: '100%'}}>
                    <ProfileHeader/>
                    <View style={{flex: 5,  justifyContent: 'space-between'}}>
                        <Records/>
                        <AchievementList toggleSwipeNav={this.props.toggleSwipeNav}></AchievementList>
                        <ElevatedView  style={{flex: 2, backgroundColor: '#2B2D42', margin: 15,  elevation: 5}}/>
                    </View>
              </View>
          </View>

      
    );
  }
}

