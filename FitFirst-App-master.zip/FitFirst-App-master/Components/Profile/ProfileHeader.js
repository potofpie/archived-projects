//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Image} from 'react-native';


import tmpPic from '../../Resources/tom.jpg';
import { Avatar } from 'react-native-elements';
import ElevatedView from 'react-native-elevated-view';

//Styles
import globalStyle from '../../Styles/globalStyle';
import headerStyle from '../../Styles/headerStyle';

export default class ProfileHeader extends Component{
    constructor(props) {
        super(props);
        //API CALL HERE
        this.state = { name: 'Tom',
                       username: 'tom',
                       gym: 'LA Fitness ',   
               
                    };
    }

  render() {
    return (
      <View style={headerStyle.header}>
          <View style={headerStyle.flexRow}>
            <View style={headerStyle.left}>
                <ElevatedView elevation={5} style={headerStyle.pictureContainer}> 
                  <Image style={headerStyle.picture} source={tmpPic} resizeMode='contain'/>
                </ElevatedView>
            </View>
            <View style={headerStyle.right}>
                <Text style={headerStyle.nameText}>Tom</Text>
                <Text style={headerStyle.gymText}> LA Fitness</Text>
                <Text style={headerStyle.usernameText}> @tom</Text>
              
            </View>

          </View>
      </View>
    );
  }
}
