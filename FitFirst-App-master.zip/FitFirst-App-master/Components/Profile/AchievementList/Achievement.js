//Component
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, Image, View, ScrollView} from 'react-native';
import Record from '../RecordList/Record.js';
import { Divider } from 'react-native-elements';
import ElevatedView from 'react-native-elevated-view';



//Resources
import run1 from '../../../Resources/Achievements/1st-running.png';
import run2 from '../../../Resources/Achievements/2st-running.png';
import run3 from '../../../Resources/Achievements/3st-running.png';


//Styles
import globalStyle from '../../../Styles/globalStyle';
import achievementListStyle from '../../../Styles/achievementListStyle'




export default class RecordList extends Component{
  render() {
    return (
        <View style={achievementListStyle.achievementContainer}>                       
            <Image source={this.props.pic} style={achievementListStyle.picture}/>
            <Text>{this.props.name}</Text>
        </View>

    );
  }
}
