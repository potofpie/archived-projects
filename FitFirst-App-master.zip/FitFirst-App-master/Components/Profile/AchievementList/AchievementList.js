//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, Image, View, ScrollView, Dimensions} from 'react-native';
import Record from '../RecordList/Record.js';
import { Divider } from 'react-native-elements';
import ElevatedView from 'react-native-elevated-view';
import Achievement from './Achievement.js';



//Resources
import jogger from '../../../Resources/jogger.png';
import speedster from '../../../Resources/speedster.png';
import flash from '../../../Resources/flash.png'


//Styles
import globalStyle from '../../../Styles/globalStyle';
import achievementListStyle from '../../../Styles/achievementListStyle'


export default class RecordList extends Component{
  constructor(){
    super();
    this.state = { x: null, y: null, width: null, height: null }
  }



  render() {
    
    let screenHeight = Dimensions.get('window').height;
    let screenWidth = Dimensions.get('window').width;
    return (
      <View  style={{flex: 1, backgroundColor: '#2B2D42', margin: 15,  elevation: 5}}>
          <ScrollView
          scrollEventThrottle={16}
          pagingEnabled
          scrollEnabled={true}
          >
            <View style={{ flex: 1,height: 67, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                <Image style={{flex: 1, height: '80%'}} source={flash} resizeMode='contain'/>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                    <Text style={achievementListStyle.statText}>Flash</Text>
                    <Text style={achievementListStyle.desText}>You ran a mile in under 6 minutes.</Text>
                </View>
            </View>
            <View style={{ flex: 1,height: 67, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                <Image style={{flex: 1, height: '80%'}} source={speedster} resizeMode='contain'/>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                    <Text style={achievementListStyle.statText}>Speedster</Text>
                    <Text style={achievementListStyle.desText}>You ran a mile in under 8 minutes.</Text>
                </View>
            </View>
            <View style={{ flex: 1,height: 67, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                <Image style={{flex: 1, height: '80%'}} source={jogger} resizeMode='contain'/>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                    <Text style={achievementListStyle.statText}>Jogger</Text>
                    <Text style={achievementListStyle.desText}>You ran a mile in under 10 minutes.</Text>
                </View>
            </View>




          </ScrollView>
      </View>
    );
    
  }
}
