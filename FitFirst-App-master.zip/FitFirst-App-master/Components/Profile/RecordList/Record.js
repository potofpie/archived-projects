//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';

//Styles
import globalStyle from '../../../Styles/globalStyle';


export default class Record extends Component{
  render() {
    return (
      <View>
           <Text style={globalStyle.contentText}> <Text style={{fontWeight: "bold"}}>{this.props.name} : </Text> {this.props.data}</Text>
      </View>
    );
  }
}
