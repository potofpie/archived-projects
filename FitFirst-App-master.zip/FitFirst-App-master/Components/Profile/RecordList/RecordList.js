//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import Record from './Record.js';
import { Divider } from 'react-native-elements';
import ElevatedView from 'react-native-elevated-view';

//Styles
import globalStyle from '../../../Styles/globalStyle';
import recordListStyle from '../../../Styles/recordListStyle'




export default class RecordList extends Component{
  render() {
    return (
      <ElevatedView style={recordListStyle.records}>
      <View style={{ flex: 120, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={recordListStyle.statText}>7<Text style={recordListStyle.unitText}> miles</Text></Text>
        <Text style={recordListStyle.desText}>longest distance</Text>
      </View>
      <View style={recordListStyle.line}></View>
      <View style={{ flex: 100, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={recordListStyle.statText}>8:13</Text>
        <Text style={recordListStyle.desText}>fastest mile</Text>
      </View>
      <View style={recordListStyle.line}></View>
      <View style={{ flex: 120, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={recordListStyle.statText}>3<Text style={recordListStyle.unitText}> d/w</Text></Text>
        <Text style={recordListStyle.desText}>scedule constance</Text>
      </View>
      
      </ElevatedView>
    );
  }
}

