//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, ScrollView} from 'react-native';

//Styles
import globalStyle from '../../Styles/globalStyle';


export default class Profile extends Component{
  render() {
    return (
      <View style={globalStyle.pageContainer}>
        <Text style={{fontSize: 60}}>Social</Text>
      </View>
    );
  }
}

