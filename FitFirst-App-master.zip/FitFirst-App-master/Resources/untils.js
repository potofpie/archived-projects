export const Fonts = {
    MontSerrat: 'Montserrat-Regular'
}