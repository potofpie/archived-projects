//Components
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, ScrollView, View, Dimensions} from 'react-native';
import Profile from './Components/Profile/Profile.js'
import Social from './Components/Social/Social.js'
import Camera from './Components/Camera/Camera.js'



//Styles
import globalStyle from './Styles/globalStyle'




export default class App extends Component{
  constructor(props) {
    super(props);
    //API CALL HERE
    this.state = { 
                  swipeNavScollEnabled: true, 
                };
  }
  toggleSwipeNav = (toggle) => {
    
   
  }

  render() {
    
    let screenHeight = Dimensions.get('window').height;
    let screenWidth = Dimensions.get('window').width;
    
    return (
          <ScrollView horizontal pagingEnabled snapToAlignment='end' scrollEnabled={this.state.swipeNavScollEnabled} >
                    <Profile toggleSwipeNav={this.toggleSwipeNav}/>
                    <Social/>
                    <Camera/>
          </ScrollView>

      
    );
  }
}

