package com.example.root.checkbox2;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.ImageView;

public class FinalOrder extends Activity {

    ImageView ivs[];
    Intent i;
    int[] array;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_order);
        ivs = new ImageView[4];
        ivs[0] = findViewById(R.id.cheese);
        ivs[1] = findViewById(R.id.lettuce);
        ivs[2] = findViewById(R.id.tom);
        ivs[3] = findViewById(R.id.on);


        i = getIntent();
        array = i.getIntArrayExtra("info");

        for(int i = 0; i < 4; i++)
        {
            if(array[i] == 0)
            {
                ivs[i].setVisibility(View.GONE);
            }
        }




    }

}
