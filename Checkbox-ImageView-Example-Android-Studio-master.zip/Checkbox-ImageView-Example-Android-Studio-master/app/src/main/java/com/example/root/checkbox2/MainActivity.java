package com.example.root.checkbox2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends Activity {

    CheckBox checkBoxs[];
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.b0);


        checkBoxs = new CheckBox[6];

        checkBoxs[0] = findViewById(R.id.cb0);
        checkBoxs[1] = findViewById(R.id.cb1);
        checkBoxs[2] = findViewById(R.id.cb2);
        checkBoxs[3] = findViewById(R.id.cb3);


        button.setOnClickListener(new View.OnClickListener() {
            //The code in this function will run when the button is clicked
            public void onClick(View v) {
                int[] array = new int[6];
                for(int i = 0; i < 4; i++)
                {
                    if(checkBoxs[i].isChecked())
                    {
                        array[i] = 1;
                    }

                }
                Intent i = new Intent(MainActivity.this, FinalOrder.class);
                i.putExtra("info", array);
                startActivity(i);
            }
        });
    }
}
