# Bobs Calculator

This is a small project to refresh my knowlegde of Android Studio.  The end goal is to make a calculator with most of the features you would find on any default calculator app.


## Icons made by:

- Icons made by Freepik from www.flaticon.com

- Icons made by Twitter from www.flaticon.com

- Icons made by Smashicons from www.flaticon.com

## App Demo:
![First view](https://media.giphy.com/media/toKRN5RrzxApdgOI5t/giphy.gif)

## Virtual Device:

After cloning this repository you will need to setup a virtual device with a screen size of 5.1 inches.  This will make for the best user experience. I have designed this app with the Galaxy S 5 in mind.  
