package com.example.bobbychristopher.bobbyscalculator;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    public Boolean op= false, add = false, multi = false, sub = false, div = false;
    public TextView display;
    public String saveString;
    public int saveOp;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.info) {
           // Toast.makeText(MainActivity.this, "This is my Toast message!",
           //         Toast.LENGTH_LONG).show();
            startActivity(new Intent(MainActivity.this, InfoPage.class));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GridView gridview = (GridView) findViewById(R.id.gridview);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorBlue)));
        getSupportActionBar().setTitle("Bobby's Calculator");
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.colorDarkBlue));
        }

        display = (TextView) findViewById(R.id.display);
        display.setText("0");
        gridview.setAdapter(new ButtonImageAdapter(this));
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                pickNumber(position);
            }
        });
    }
    public Boolean checkZero() {
        return display.getText().equals("0");
    }
    public void storeDisplayText()
    {
        saveString= display.getText().toString();
    }
    public String cutOffZeros(String answer)
    {
        if(answer.contains(".")) {
            int zeroCount = 0;
            Log.d("Tag", answer);
            StringBuilder sb = new StringBuilder(answer);
            for (int i = 0; i < answer.length(); i++) {
                if (answer.charAt(i) == '0') {
                    zeroCount++;
                } else {
                    zeroCount = 0;
                }
            }
            switch (zeroCount) {
                case 0:
                    Log.d("Tag", "0");
                    return sb.toString();

                case 1:
                    sb.deleteCharAt(7);
                    Log.d("Tag", "1");
                    return sb.toString();
                case 2:
                    sb.deleteCharAt(6);
                    sb.deleteCharAt(5);
                    Log.d("Tag", "2");
                    return sb.toString();
                case 3:
                    sb.deleteCharAt(7);
                    sb.deleteCharAt(6);
                    sb.deleteCharAt(5);
                    Log.d("Tag", "3");
                    return sb.toString();
                case 4:
                    sb.deleteCharAt(7);
                    sb.deleteCharAt(6);
                    sb.deleteCharAt(5);
                    sb.deleteCharAt(4);
                    Log.d("Tag", "4");
                    return sb.toString();
                case 5:
                    sb.deleteCharAt(7);
                    sb.deleteCharAt(6);
                    sb.deleteCharAt(5);
                    sb.deleteCharAt(4);
                    sb.deleteCharAt(3);
                    Log.d("Tag", "5");
                    return sb.toString();
                case 6:
                    sb.deleteCharAt(7);
                    sb.deleteCharAt(6);
                    sb.deleteCharAt(5);
                    sb.deleteCharAt(4);
                    sb.deleteCharAt(3);
                    sb.deleteCharAt(2);
                    sb.deleteCharAt(1);
                    Log.d("Tag", "6");
                    return sb.toString();
            }
            return "error";
        }
        return answer;
    }
    public String doMath()
    {
        switch (saveOp)
        {
            case 0:
                if(display.getText().toString().contains(".") || saveString.contains("."))
                {
                    return String.format("%f" ,Float.parseFloat(display.getText().toString()) + Float.parseFloat(saveString));
                }
                else {
                    return String.format("%d", Integer.parseInt(display.getText().toString()) + Integer.parseInt(saveString));
                }
            case 1:
                if(display.getText().toString().contains(".") || saveString.contains("."))
                {
                    return String.format("%f" ,Float.parseFloat(saveString) - Float.parseFloat(display.getText().toString()));
                }
                else {
                    return String.format("%d", Integer.parseInt(saveString) - Integer.parseInt(display.getText().toString()));
                }
            case 2:
                if(display.getText().toString().contains(".") || saveString.contains("."))
                {
                    return String.format("%f" ,Float.parseFloat(display.getText().toString()) * Float.parseFloat(saveString));
                }
                else {
                    return String.format("%d", Integer.parseInt(display.getText().toString()) * Integer.parseInt(saveString));
                }
            case 3:
                if(display.getText().toString().contains(".") || saveString.contains(".") || Integer.parseInt(saveString) % Integer.parseInt(display.getText().toString()) != 0)
                {
                    return String.format("%f" ,Float.parseFloat(saveString) / Float.parseFloat(display.getText().toString()));
                }
                else {
                    return String.format("%d", Integer.parseInt(saveString) / Integer.parseInt(display.getText().toString()));
                }
        }
        return "error";
    }
    public void pickNumber(int position) {
        if(position == 0) {
            if(!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "7");
                } else {
                    display.setText("7");
                }
            }
            else {
                display.setText("7");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;

            }
        }
        if(position == 1) {
            if(!op) {
                if(!checkZero()) {
                    display.setText(display.getText() + "8");
                }
                else{
                    display.setText("8");
                }
            }
            else{
                display.setText("8");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;

            }
        }
        if (position == 2) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "9");
                } else {
                    display.setText("9");
                }
            }
            else {
                display.setText("9");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 3) {
            storeDisplayText();
            saveOp = 3;
            div = true;
            op = true;
        }
        ///this is were you continue
        if(position == 4) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "4");
                } else {
                    display.setText("4");
                }
            }
            else {
                display.setText("4");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 5) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "5");
                } else {
                    display.setText("5");
                }
            }
            else {
                display.setText("5");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 6) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "6");
                } else {
                    display.setText("6");
                }
            }
            else {
                display.setText("6");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 7) {
            multi = true;
            op = true;
            storeDisplayText();
            saveOp = 2;
        }
        if(position == 8) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "1");
                } else {
                    display.setText("1");
                }
            }
            else {
                display.setText("1");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 9) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "2");
                } else {
                    display.setText("2");
                }
            }
            else {
                display.setText("2");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 10) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "3");
                } else {
                    display.setText("3");
                }
            }
            else {
                display.setText("3");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }

        }
        if(position == 11) {
            sub = true;
            op = true;
            storeDisplayText();
            saveOp = 1;
        }
        if(position == 12) {
            if (!op) {
                if (!checkZero()) {
                    display.setText(display.getText() + "0");
                }
            }
        }
        if(position == 13) {
            if (!op) {
                display.setText(display.getText() + ".");
            }
            else{
                display.setText("0.");
                op = false;
                add = false;
                multi = false;
                sub = false;
                div = false;
            }
        }
        if(position == 14) {
            display.setText("0");
            op = false;
            add = false;
            multi = false;
            sub = false;
            div = false;
        }
        if(position == 15) {
            add = true;
            op = true;
            storeDisplayText();
            saveOp = 0;
        }
        if(position == 16) {

            display.setText(cutOffZeros(doMath()));
            op = false;
            add = false;
            multi = false;
            sub = false;
            div = false;

        }
    }
}
