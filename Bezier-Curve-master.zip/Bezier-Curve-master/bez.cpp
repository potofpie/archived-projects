#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <GL/glut.h>
#include <pthread.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>

struct Point{
  float x;
  float y;
};


Point p[4];
float ss;

Point doTheThing(Point pA, Point pB, Point pC, Point pD, float x)
{
  Point pFinal;

  pFinal.x = pow(1 - x, 3) * pA.x +
  pow (1 - x, 2) * 3 * x * pB.x +
  (1-x) * 3 * x * x * pC.x +
  x * x * x * pD.x;

  pFinal.y = pow(1 - x, 3) * pA.y +
  pow (1 - x, 2) * 3 * x * pB.y +
  (1-x) * 3 * x * x * pC.y +
  x * x * x * pD.y;

  return pFinal;
}

void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT);
   glBegin(GL_POINTS);
   //printf("p[0] :| x - %f, y - %f | p[1] :| x - %f, y - %f |  p[2] :| x - %f, y - %f |  p[3] :| x - %f, y - %f |",p[0].x,p[0].y,p[1].x,p[1].y,p[2].x,p[2].y,p[3].x,p[3].y);
   for(float i = 0.0; i < 1.0; i+=ss)
   {
     //GREEN
     glColor3f(0.0f, 1.0f, 0.0f);
     glVertex3f(doTheThing(p[0],p[1],p[2],p[3],i).x, doTheThing(p[0],p[1],p[2],p[3],i).y, -1.0f);
   }
   glColor3f(1.0f, 1.0f, 0.0f);
   glVertex3f(p[0].x,p[0].y, -1.0f);
   glVertex3f(p[1].x,p[1].y, -1.0f);
   glVertex3f(p[2].x,p[2].y, -1.0f);
   glVertex3f(p[3].x,p[3].y, -1.0f);
   glEnd ();
   glutSwapBuffers();
}
void mloop(int v)
{
  //printf("in mainloop\n");
  display();
  //glutTimerFunc(1000/60, mloop, v);

}
void reshape(int w, int h)
{
  //printf("reshape\n");
}
void mouse(int btn, int state, int x, int y)
{
  //printf("button: %d    state: %d    x: %d  y: %d\n", btn, state, x, y);
}
void keyboard(unsigned char key, int x, int y)
{
	//printf("keypress: %d    x: %d    y: %d\n", key, x, y);

}
void mouseMotion(int x, int y)
{
  //printf("x: %d  y: %d\n", x, y);
}

int createWindow(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitWindowSize (1020, 980);
  glutCreateWindow (argv[0]);
  glutReshapeFunc (reshape);
  glutKeyboardFunc (keyboard);
  glutMouseFunc(mouse);
  glutPassiveMotionFunc(mouseMotion);
  glutTimerFunc(1000/60, mloop, 0); /* 60 == frame rate */
  //glutDisplayFunc (display);
  glutMainLoop();
}
int main(int argc, char *argv[])
{
  //printf("%d\n", argc);
  if(argc != 10){
    puts("bez.cpp |: ./bez p0 p1 p2 p3 ss\n | p = control point | ss = step size |");
    return 0;
  }
  for(int i = 1; i < 10; i++){
    if(atof(argv[i]) < -1 || atof(argv[i]) > 1 ){
      puts("All control points and step size must be:\n p > -1.00 && p < 1.00");
      return 0;
    }
  }
  //error checking

  ss = atof(argv[9]);
  //int c = 1;
  for(int i = 0; i < 4; i++){
    p[i].x = atof(argv[(i*2)+1]);
    p[i].y = atof(argv[(i*2)+2]);
    //printf("x%d|: %f\n",i, p[i].x);
    //printf("y%d|: %f\n",i, p[i].y);

  }
  //printf("ss|: %f\n", ss);
  createWindow(argc, argv);
   return 0;
}
