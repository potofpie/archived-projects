import React, { Component } from 'react';
import '../Styles/lowercontainer.css';

class LowerContainer extends Component {
  render() {
    return (
      <div className="LowerContainer">

      </div>
    );
  }
}

export default TitleBar;
