import React, { Component } from 'react';
import maps from '../Resources/maps.png';
import graph from '../Resources/graph.png';
import instruct from '../Resources/instruct.png';
import credits from '../Resources/credits.png';
import truck from '../Resources/truck.png';
import '../Styles/sidebar.css';

class Sidebar extends Component {
  click(page){
    console.log("clicked " + page);
    this.props.press(page);
  }
  clickInfo(){
    console.log("clicked info");
  }
  clickMaps(){
    console.log("clicked Maps");
  }
  clickGraph(){
    console.log("clicked Graph");
  }
  clickCredits(){
    console.log("clicked Credit");
  }
  clickTruck(){
    console.log("clicked Truck");
  }
  render() {
    return (
      <div className="Sidebar">
          <img onClick={(e) => {this.click("instruct")}} src={instruct} className="Sidebar-button" alt="logo" />
          <img onClick={(e) => {this.click("truck")}} src={truck} className="Sidebar-button" alt="logo" />
          <img onClick={(e) => {this.click("maps")}} src={maps} className="Sidebar-button" alt="logo" />
          <img onClick={(e) => {this.click("graph")}} src={graph} className="Sidebar-button" alt="logo" />
          <img onClick={(e) => {this.click("credits")}} src={credits} className="Sidebar-button" alt="logo" />
      </div>
    );
  }
}

export default Sidebar;
