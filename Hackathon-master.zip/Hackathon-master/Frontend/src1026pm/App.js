import React, { Component } from 'react';
import Sidebar from './Components/Sidebar.js'
import TitleBar from './Components/TitleBar.js'
import './App.css';

class App extends Component {



   constructor(props){
    super(props);
    this.state =  {
      map:0,
      graph: 0,
      instruct: 1,
      credits: 0,
      truck: 0
    }
  }

  pickPage(){
    if(this.state.map === 1){
      return <p className="App-intro">maps</p>
    }
      else{
        if(this.state.graph === 1){
          return <p className="App-intro">graph</p>
        }
          else{
            if(this.state.instruct === 1){
              return <p className="App-intro">instruct</p>
            }
            else{
              if(this.state.credits === 1){
                return <p className="App-intro">credits</p>
              }
              else{
                if(this.state.truck === 1){
                  return <p className="App-intro">truck</p>
                }
                else{}
        }
      }
    }
  }
}

  ToolCallBack = (button) => {
    if("maps" === button){
      this.setState({
        map:1,
        graph: 0,
        instruct: 0,
        credits: 0,
        truck: 0
      });
    }
      else{
        if("graph" === button){
          this.setState({
            map:0,
            graph: 1,
            instruct: 0,
            credits: 0,
            truck: 0
          });
        }
          else{
            if("instruct" === button){
              this.setState({
                map:0,
                graph: 0,
                instruct: 1,
                credits: 0,
                truck: 0
              });
            }
            else{
              if("credits" === button){
                this.setState({
                  map:0,
                  graph: 0,
                  instruct: 0,
                  credits: 1,
                  truck: 0
                });
              }
              else{
                if("truck" === button){
                  this.setState({
                    map:0,
                    graph: 0,
                    instruct: 0,
                    credits: 0,
                    truck: 1
                  });
                }
                else{}
        }
      }
    }
  }
}


  render() {
    return (
      <div className="App">
        <TitleBar bg="#af5320"/>
        <Sidebar press={this.ToolCallBack} />
        {this.pickPage()}
      </div>
    );
  }
}

export default App;
