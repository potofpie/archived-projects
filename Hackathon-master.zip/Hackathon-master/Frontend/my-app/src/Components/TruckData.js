import React, { Component } from 'react';
import LineGraph from './LineGraph';
import '../Styles/titlebar.css';
import truck from '../Resources/truck.png';
import t1 from '../Resources/truck1.png';
import t2 from '../Resources/truck2.png';
import t4 from '../Resources/truck4.png';
import t6 from '../Resources/truck6.png';
import t7 from '../Resources/truck7.png';
import t8 from '../Resources/truck8.png';
import t9 from '../Resources/truck9.png';
import t10 from '../Resources/truck10.png';
import t11 from '../Resources/truck11.png';
import t12 from '../Resources/truck12.png';
import t13 from '../Resources/truck13.png';
import t15 from '../Resources/truck15.png';
import t16 from '../Resources/truck16.png';
import axios from 'axios';

class TruckData extends Component {

  constructor(props){
        super(props);
        this.state = {
            truck: 0,
            j: [0]
        }
        this.click = this.click.bind(this);
    }

    click(n){
        console.log("button " + n + " clicked");
        var blah = [1,2,4,6,7,8,9,10,11,12,13,15,16];
        var truckNum = blah[n];
        //console.log("Asking: " + truckNum);
        var _this = this;
        this.serverRequest =
        axios
            .get("http://127.0.0.1:5000/truckSET", {
                params: {
                    startDate: "02/01/2018",
                    endDate: "2/11/2018",
                    truck: truckNum
                }
            })
            .then(function(result) {
                console.log("Returned Data: " + result.data);
                _this.setState({
                    j: result.data
                });
            })
    }

    pickTruck(){
            console.log("Data Putting into Truck Is: " + this.state.j);
            return <LineGraph tData={this.state.j}/>
    }


    render() {

        console.log("Rendering!");

        return (
            <div>
                <div>
                    <img src={t1} className="Truckbutton" onClick={() => this.click(1)}/>
                    <img src={t2} className="Truckbutton" onClick={() => this.click(2)}/>
                    <img src={t4} className="Truckbutton" onClick={() => this.click(3)}/>
                    <img src={t6} className="Truckbutton" onClick={() => this.click(4)}/>
                    <img src={t7} className="Truckbutton" onClick={() => this.click(5)}/>
                    <img src={t9} className="Truckbutton" onClick={() => this.click(6)}/>
                    <img src={t10} className="Truckbutton" onClick={() => this.click(7)}/>
                    <img src={t11} className="Truckbutton" onClick={() => this.click(8)}/>
                    <img src={t12} className="Truckbutton" onClick={() => this.click(9)}/>
                    <img src={t13} className="Truckbutton" onClick={() => this.click(10)}/>
                    <img src={t15} className="Truckbutton" onClick={() => this.click(11)}/>
                    <img src={t16} className="Truckbutton" onClick={() => this.click(12)}/>

                </div>
                {this.pickTruck()}
            </div>
        );
    }

}

export default TruckData;
