import React, { Component } from 'react';
import axios from 'axios'

class LineGraph extends Component {
    constructor(props) {
        super(props);
        console.log("I'm made");

        console.log(this.props.tData)
        this.state = { truck: 0, hours: this.props.tData };

      }


    render() {


        var LineData = {
            labels: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            datasets: [
                {
                    label: "Truck 1",
                    fillColor: "rgba(220,220,220,0.2)",
                    strokeColor: "rgba(220,220,220,1)",
                    pointColor: "rgba(220,220,220,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: this.props.tData
                }
            ],
            options: {scaleBeginAtZero: true, scaleMaxValue: 12.0}
        };

        var lineOptions = {scaleBeginAtZero: true}




    var LineChart = require("react-chartjs").Line;
    //var BarChart = require("react-chartjs").Bar;
    //new Chart(ctx).PolarArea(PolarData);
    //<PolarChart data={PolarData} width="600" height="250"/>

    //console.log(this.props.data);

    return (
        <div className="App">
            <LineChart data={LineData} options={lineOptions} width="1000" height="400"/>
        </div>
    );
  }
}


export default LineGraph;
