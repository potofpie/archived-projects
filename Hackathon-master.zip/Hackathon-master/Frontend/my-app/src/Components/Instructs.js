import React, { Component } from 'react';
import '../Styles/titlebar.css';

class Credits extends Component {
  render() {
      var titleStyle = {
          backgroundColor: this.props.bg,
      }
    return (
      <div>
            <h1> Instructions </h1>
            <p>
            Please select a tab from the left sidebar to begin.
            </p>
            <p>
            Available options are:
            </p>
            <p>
            View Instruction Page (You are Here!)
            </p>
            <p>
            View Truck Data
            </p>
            <p>
            View Map
            </p>
            <p>
            View Graphs of Data
            </p>
            <p>
            View Credits
            </p>
      </div>
    );
  }
}

export default Credits;
