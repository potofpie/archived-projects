import React, { Component } from 'react';
import '../Styles/titlebar.css';

class TitleBar extends Component {
  render() {
      var titleStyle = {
          backgroundColor: this.props.bg,
      }
    return (
      <div>
        <header className="Header" style={titleStyle}>
            <h1>Schenectady Sanitation Information</h1>
        </header>
      </div>
    );
  }
}

export default TitleBar;
