import React, { Component } from 'react';



class ColorBlock extends Component {
	render()	{	
    var	blockStyle	= {
			backgroundColor: "#AF5320"
		};										
				return(																						
					<div style={blockStyle}>
					</div>
    );
  }
}

export default ColorBlock;