import React, { Component } from 'react';
import '../Styles/titlebar.css';

class Credits extends Component {
  render() {
      var titleStyle = {
          backgroundColor: this.props.bg,
      }
    return (
      <div>
            <h1> Credits </h1>
            <p>
            <strong>Moral Support </strong>- Siegfreid the Penguin
            </p>
            <p>
            <strong>Dev Team</strong> - Dennis Champagne, Bobby Christopher, Jack Dacey, Dylan Gebel, Greg Hadjiyane, Cael Hansen, and Mike Otten
            </p>
            <h3> Icons </h3>
            <p>
            Map icon made by Freepik from www.flaticon.com
            </p>
            <p>
            Garbage Truck icon made by Smashicons from www.flaticon.com
            </p>
            <p>
            Graph icon made by Smashicons from www.flaticon.com
            </p>
            <p>
            Question Mark icon made by Freepik from www.flaticon.com
            </p>
            <p>
            Penguin icon made by Freepik from www.flaticon.com
            </p>
      </div>
    );
  }
}

export default Credits;
