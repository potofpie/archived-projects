import React, { Component } from 'react';
import './LineGraph';
import axios from 'axios'
import TruckData from './TruckData';

class GraphTest extends Component {
    constructor(props) {
        super(props);

        this.state = { j: "7.7", trucks: [7.5, 6.1, 6.6, 5.7, 7.8, 8.0, 5.6, 6.3, 7.6, 5.2, 5.7, 6.6, 4.5] };

        console.log(this.state.j);
      }


      componentDidMount() {
        var _this = this;
        this.serverRequest =
          axios
            .get("http://127.0.0.1:5000/truckAVG", {
                params: {
                    startDate: "02/01/2018",
                    endDate: "2/11/2018"
                }
            })
            .then(function(result) {
                console.log(result);
              _this.setState({
                j: result.statusText
              });
            })
      }

    render() {

        console.log('hello');
        console.log(this.state.j);




        var BarData = {
            labels: ["Truck 1", "Truck 2", "Truck 3", "Truck 4", "Truck 5", "Truck 6", "Truck 7", "Truck 8", "Truck 9", "Truck 10", "Truck 11", "Truck 12", "Truck 13"],
            datasets: [
                /*{
                    label: "Current Week",
                    fillColor: "rgba(220,220,220,0.2)",
                    strokeColor: "rgba(220,220,220,1)",
                    pointColor: "rgba(220,220,220,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: [65, 59, 80, 81, 56, 55, 40]
                },*/
                {
                    label: "Last Week",
                    fillColor: "rgba(151,187,205,0.2)",
                    strokeColor: "rgba(151,187,205,1)",
                    pointColor: "rgba(151,187,205,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(151,187,205,1)",
                    data: this.state.trucks
                }
            ]
        };



    //var LineChart = require("react-chartjs").Line;
    var BarChart = require("react-chartjs").Bar;
    //new Chart(ctx).PolarArea(PolarData);
    //<PolarChart data={PolarData} width="600" height="250"/>

    return (

        <div className="App">
            <h1>Weekly Average</h1>
            <br/>
            <BarChart data={BarData} width="1000" height="400"/>
        </div>
    );
  }
}


export default GraphTest;
