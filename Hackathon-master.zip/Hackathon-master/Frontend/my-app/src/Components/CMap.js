import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react'

/* AIzaSyCC-s53YeHSTbfNP5PpcZMGW8cffAfIkUI */


 const AnyReactComponent = ({ text }) => <div>{ text}</div>;

 var size = {
    height: 10,
    width: 10,
};

 export default class CMap extends Component {
     static defaultProps = {
         center: { lat: 40.7473310, lng: -73.9485420 },
        zoom: 11,
     }

     render() {
         return (
            <div className='size'>
             <div className='google-map'>
             <GoogleMapReact 
             bootstrapURLKeys={{key: 'AIzaSyCC-s53YeHSTbfNP5PpcZMGW8cffAfIkUI'}}
            defaultCenter={ this.props.center }
            defaultZoom={ this.props.zoom }>
            <AnyReactComponent
                lat={ 40.7473310}
                lng={ -73.8517440}
                text={ 'wheres walauigie' }
                />
                </GoogleMapReact>
            </div>
            </div>
         )
     }
 }




/*
class CMap extends Component {
    componentDidMount() {
        this.loadMap();
      }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.google !== this.props.google) {
            this.loadMap();
        }
    }
    loadMap() {
        if(this.props && this.props.google) {
            // google is available
            const {google} = this.props;
            const maps = 'google.maps'

            const mapRef = this.refs.map;
            //const node = this.findDOMNode(mapRef);

            let zoom = 14;
            let lat = 37.774929;
            let lng = -122.419416;
            const center = new maps.latlng(lat, lng);
            const mapConfig = Object.assign({}, {
                center: center,
                zoom: zoom 
            })
            this.map = new maps.CMap(mapConfig);

        }
    }
	render()	{											
		return(																						
			<div ref='map'>
                loading map...
			</div>
    );
  }
}

export default CMap;
*/