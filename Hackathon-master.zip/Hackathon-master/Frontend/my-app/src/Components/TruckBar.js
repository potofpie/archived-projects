import React, { Component } from 'react';
import '../Styles/truckbar.css';

class TitleBar extends Component {
  constructor(props){
   super(props);
   this.state =  {
     trucks: this.props.trucks,
   }
   button(i){

     return <button> i </button>
   }
 }
  render() {
    return (
      <div className="Truckbar">
      for (i = 0; i < trucks.length; i++) {
        {this.button()}
      }
      </div>
    );
  }
}

export default TitleBar;
