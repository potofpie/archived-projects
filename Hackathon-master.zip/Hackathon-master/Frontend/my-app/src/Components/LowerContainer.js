import React, { Component } from 'react';
import Sidebar from './Sidebar.js'
import Credits from './Credits.js'
import Graph from './graphtest.js'
import TrackData from './TruckData.js'
import Instructs from './Instructs.js';
import CMap from './CMap.js'
import '../Styles/lowercontainer.css';
import '../Styles/graphtest.css';

class LowerContainer extends Component {

  constructor(props){
   super(props);
   this.state =  {
     map:0,
     graph: 0,
     instruct: 1,
     credits: 0,
     truck: 0
   }
 }

 pickPage(){
   if(this.state.map === 1){
     return <CMap className="CMaps" />
   }
     else{
       if(this.state.graph === 1){
         return <div><Graph /></div>
       }
         else{
           if(this.state.instruct === 1){
             return <Instructs />
           }
           else{
             if(this.state.credits === 1){
               return <div><Credits/></div>
             }
             else{
               if(this.state.truck === 1){
                 return <TrackData />
               }
               else{
                 return <Instructs />
               }
       }
     }
   }
 }
}

 ToolCallBack = (button) => {
   if("maps" === button){
     this.setState({
       map:1,
       graph: 0,
       instruct: 0,
       credits: 0,
       truck: 0
     });
   }
     else{
       if("graph" === button){
         this.setState({
           map:0,
           graph: 1,
           instruct: 0,
           credits: 0,
           truck: 0
         });
       }
         else{
           if("instruct" === button){
             this.setState({
               map:0,
               graph: 0,
               instruct: 1,
               credits: 0,
               truck: 0
             });
            }
           else{
             if("credits" === button){
               this.setState({
                 map:0,
                 graph: 0,
                 instruct: 0,
                 credits: 1,
                 truck: 0
               });
             }
             else{
               if("truck" === button){
                 this.setState({
                   map:0,
                   graph: 0,
                   instruct: 0,
                   credits: 0,
                   truck: 1
                 });
               }
               else{}
       }
     }
   }
 }
}

  render() {


    return (
      <div className="LowerContainer">
      <Sidebar press={this.ToolCallBack} />
      {this.pickPage()}
      </div>
    );
  }
}

export default LowerContainer;
