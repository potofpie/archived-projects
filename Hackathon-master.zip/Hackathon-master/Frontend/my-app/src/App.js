import React, { Component } from 'react';
import Sidebar from './Components/Sidebar.js'
import TitleBar from './Components/TitleBar.js'
import LowerContainer from './Components/LowerContainer.js'
import './App.css';

class App extends Component {

  render() {
    return (
      <div className="App">
        <TitleBar bg="#0B002F"/>
        <LowerContainer/>
      </div>
    );
  }
}

export default App;
