package com.example.root.radiobutton;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends Activity {
    int i;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //The two elements in our xml file
        Button button = findViewById(R.id.b0);

            button.setOnClickListener(new View.OnClickListener() {
                //The code in this function will run when the button is clicked
                public void onClick(View v) {
                    String s = "Radio Button: " + i;
                    Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
                }
            });

    }

    public void DoToast(int i)
    {
        Toast.makeText(MainActivity.this, "You ", Toast.LENGTH_LONG).show();
    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()){
            case R.id.rb0:
                if (checked)
                {
                    i = 0;
                    break;
                }

            case R.id.rb1:
                if (checked)
                {
                    i = 1;
                    break;
                }

            case R.id.rb2:
                if (checked)
                {
                    i = 2;
                    break;
                }

            case R.id.rb3:
                if (checked)
                {
                    i = 3;
                    break;
                }

            case R.id.rb4:
                if (checked)
                {
                    i = 4;
                    break;
                }

            case R.id.rb5:
                if (checked)
                {
                    i = 5;
                    break;
                }

        }
    }
}
