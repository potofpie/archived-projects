import requests
import time
apiKey = 'RGAPI-bb4ec84f-7eeb-4f21-a0ea-488f277d78c1'

#TODO
#add something to catch error when json object is incorrect
def getPlayerData(uName):
    url = 'https://na1.api.riotgames.com/lol/summoner/v3/summoners/by-name/' + uName + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    playerData =  jsonObject.json()
    return playerData

def getMatchData(gameId):
    url = 'https://na1.api.riotgames.com/lol/match/v3/matches/' + str(gameId) + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    matchData =  jsonObject.json()
    return matchData

def getCurrMatch(summonerId):
    url = 'https://na1.api.riotgames.com/lol/spectator/v3/active-games/by-summoner/' + str(summonerId) + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    matchData =  jsonObject.json()
    return matchData

def checkRequestValid(DataFromAPI):
    try:
        return [str(DataFromAPI['status']['status_code']), str(DataFromAPI['status']['message'])]
    except:
        return 1

class Player:
    def __init__(self, uName,):
        self.error = 'Nothing'
        self.playerData = getPlayerData(uName)
        self.error = checkRequestValid(self.playerData)
        if(1==self.error):
            self.username = uName
            self.id = self.playerData['id']
            self.accId = self.playerData['accountId'] #international ID
            print self.accId
            self.valid = 1
            print uName + " IS an account in the roit system."
        else:
            self.valid = 0
            if self.error[0] == '404': print uName + " is NOT an account in the roit system."
            else: print self.error

class Match:
    def __init__(self, player):
        self.error = 'Nothing'
        self.players = []
        self.matchData = getCurrMatch(player.id)
        self.error = checkRequestValid(self.matchData)
        if(1==self.error):
            #print self.matchData
            self.gameId = self.matchData['gameId']
            self.valid = 1
            self.playersInfo = self.matchData['participants']
            for p in self.playersInfo:
                self.players.append([(p['summonerName']), str(p['summonerId'])])
            print player.username + " IS in a match."
        else:
            if self.error[0] == '404': print player.username + " is NOT in a match currently."
            else: print self.error
            self.valid = 0
    def endGameCheck(self):
        while(True):
            x = getCurrMatch(self.players[0][1])
            if(1==checkRequestValid(x)):
                print str(3+(x['gameLength'] / 60)) + ":" + str(x['gameLength'] % 60)
                time.sleep(30)
            else:
                print "The game has ended!"
                break
    def checkWin(self, uName):
        self.finalData = getMatchData(self.gameId)
        for p in self.finalData['participantIdentities']:
              if(p['player']['summonerName'] == uName):
                  playerMatchId = p['participantId']
        print finalData['participants'][playerMatchId-1]['stats']['win']


###MAIN###
TestAccount = 'trashcane'
p1 = Player(TestAccount)
if(p1.valid == 0): del p1 #delete Player object if it is not valid
m1 = Match(p1)
if(m1.valid == 0): del m1 #delete Match object if it is not valid
m1.endGameCheck()
m1.checkWin(TestAccount)
#########
