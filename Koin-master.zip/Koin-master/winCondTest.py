import requests
import time
apiKey = 'RGAPI-bb4ec84f-7eeb-4f21-a0ea-488f277d78c1'

#TODO
#add something to catch error when json object is incorrect
def getPlayerData(uName):
    url = 'https://na1.api.riotgames.com/lol/summoner/v3/summoners/by-name/' + uName + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    playerData =  jsonObject.json()
    return playerData

def getMatchData(gameId):
    url = 'https://na1.api.riotgames.com/lol/match/v3/matches/' + str(gameId) + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    matchData =  jsonObject.json()
    return matchData

def getCurrMatch(summonerId):
    url = 'https://na1.api.riotgames.com/lol/spectator/v3/active-games/by-summoner/' + str(summonerId) + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    matchData =  jsonObject.json()
    return matchData

def checkWin(uName, gameId):
    finalData = getMatchData(gameId)
    for p in finalData['participantIdentities']:
          if(p['player']['summonerName'] == uName):
              playerMatchId = p['participantId']
    print finalData['participants'][playerMatchId-1]['stats']['win']


checkWin('Voyboy', 2677696956)
