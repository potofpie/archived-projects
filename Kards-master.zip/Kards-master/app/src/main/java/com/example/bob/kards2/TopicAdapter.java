package com.example.bob.kards2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by bob on 3/25/17.
 */

public class TopicAdapter extends ArrayAdapter<Topic> {
    private LayoutInflater mInflater;

    public TopicAdapter(Context context, int rid, List<Topic> list){
        super(context, rid, list);
        mInflater =
                (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        //Retrieve Data
        Topic item = (Topic) getItem(position);

        //use layout file to generate View
        View view = mInflater.inflate(R.layout.single_topic, null);


        ImageView image;
        image = (ImageView) view.findViewById(R.id.image);
        image.setImageBitmap(item.icon);

        //set username
        TextView name;
        name = (TextView) view.findViewById(R.id.name);
        name.setText(item.name);

        //set comment
        //TextView comment;
        //name = (TextView) view.findViewById(R.id.comment);
        //name.setText(item.comment);

        return view;

    }
}
