package com.example.bob.kards2;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by bob on 3/25/17.
 */

public class Card implements Parcelable {
    String title;
    String text;
        Card(){

        }
        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel out, int flags) {
            out.writeString(title);
            out.writeString(text);
        }

        public static final Parcelable.Creator<Card> CREATOR
                = new Parcelable.Creator<Card>() {
            public Card createFromParcel(Parcel in) {
                return new Card(in);
            }

            public Card[] newArray(int size) {
                return new Card[size];
            }
        };

        public Card(Parcel in) {
            title = in.readString();
            text = in.readString();
        }
    }

