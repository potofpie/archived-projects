package com.example.bob.kards2;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bob on 3/25/17.
 */

public class Topic implements Parcelable {
    public Bitmap icon;
    public String name;
    public List<Card> cardList = new ArrayList<Card>();
    Topic(){}
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(this.name);
        out.writeTypedList(cardList);
    }

    public static final Parcelable.Creator<Topic> CREATOR
            = new Parcelable.Creator<Topic>() {
        public Topic createFromParcel(Parcel in) {
            return new Topic(in);
        }

        public Topic[] newArray(int size) {
            return new Topic[size];
        }
    };

    private Topic(Parcel in) {
        name = in.readString();
        in.readTypedList(cardList, Card.CREATOR);
    }
}
