package com.example.bob.kards2;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class CardScreen extends FragmentActivity {

    private final int PAGE_COUNT=3;
    private ViewPager mViewPager;
    private PagerAdapter mPagerAdapter;
    
    Topic t = new Topic();
    public List<Card> cards = new ArrayList<Card>();
    public String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_screen);

        mViewPager = (ViewPager) findViewById(R.id.viewPager);
        mViewPager.setAdapter(mPagerAdapter);

        Intent i = getIntent();
        t = i.getParcelableExtra("Topic");
        cards = t.cardList;

    }

    private class Frag extends FragmentStatePagerAdapter {
        public Frag(FragmentManager fm) {
            super(fm);
        }
        @Override
        public Fragment getItem(int position) {
            CardFrag cardfrag = new CardFrag();
            switch (position) {
                case 0:
                    title = cards.get(0).title;
                    cardfrag.setTitle(title);
                    break;
                case 1:
                    title = cards.get(1).title;
                    cardfrag.setTitle(title);
                    break;
                case 2:
                    title = cards.get(2).title;
                    cardfrag.setTitle(title);
                    break;
            }
            return (Fragment) cardfrag;
        }

        @Override
        public int getCount() {
            return PAGE_COUNT;
        }

    }
}
