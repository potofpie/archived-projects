package com.example.bob.kards2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by bob on 3/25/17.
 */

public class CardFrag extends Fragment{
    String title;

    public CardFrag() {}

    public void setTitle(String t) {
        title=t;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.card_frag, container, false);
        TextView vTitle = (TextView) rootView.findViewById(R.id.title);
        vTitle.setText(title);
        return rootView;
    }
}
