package com.example.bob.kards2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public List<Topic> list = new ArrayList<Topic>();
    TopicAdapter adapter;

    public ArrayList<Card> makeTestCardList(){
        ArrayList<Card> cardlist = new ArrayList<Card>();
        Card card1 = new Card();
        card1.title = "Stuff";
        cardlist.add(card1);

        Card card2 = new Card();
        card2.title = "OtherStuff";
        cardlist.add(card2);

        Card card3 = new Card();
        card3.title = "MoreStuff";
        cardlist.add(card3);

        return cardlist;
     }
    public void Add(){
        Bitmap defaultImage;
        defaultImage =
                BitmapFactory.decodeResource(getResources(), R.drawable.icon_1);

        Topic item1 = new Topic();
        item1.icon = defaultImage;
        item1.name = "newTopic";
        item1.cardList = makeTestCardList();
        list.add(item1);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bitmap defaultImage;
        defaultImage =
                BitmapFactory.decodeResource(getResources(), R.drawable.icon_1);

        Topic item1 = new Topic();
        item1.icon = defaultImage;
        item1.name = "Homework";
        item1.cardList = makeTestCardList();
        list.add(item1);

        Topic item2 = new Topic();
        item2.icon = defaultImage;
        item2.name = "Cooking";
        item2.cardList = makeTestCardList();
        list.add(item2);

        Topic item3 = new Topic();
        item3.icon = defaultImage;
        item3.name = "Tech Ideas";
        item3.cardList = makeTestCardList();
        list.add(item3);

        adapter = new TopicAdapter(this, 0, list);

        //assign ListItemAdapter to ListView
        GridView gridView = (GridView) findViewById(R.id.ListView01);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Topic selected = list.get(position);
                Toast.makeText(MainActivity.this, "" + selected.name,
                        Toast.LENGTH_SHORT).show();
                sendTopic(selected);
            }
        });
    }
    public void sendTopic(Topic t){
        Intent i = new Intent(this, CardScreen.class);
        i.putExtra("Topic",t);
        startActivity(i);

    }
}
