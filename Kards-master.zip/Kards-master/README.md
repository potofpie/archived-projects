# Kards

## Desciption
This was a project I worked on with Cael Hansen in my mobile development course.  This was made with Android Studio. Although this is not that latest version of the project will be attatched a gif of the final product. The idea was to create a set of virtual index cards that the user could flip through. These stacks of cards are organized into catagories.
## First view:
![First view](https://media.giphy.com/media/jxddf3FhPImvr9rFWT/giphy.gif)

## Second view:
![Second view:](https://media.giphy.com/media/4T5wmRtLVfs2I7FWCp/giphy.gif)
