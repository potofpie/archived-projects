# Mass Text Messaging System

## Description
This Project was previous made in my free time as a text bomber to annoy my friends. It was recently been turned into a mass texting system for Serria Social Marketing. Athough this project did not come to fruition, it still works as an alernative to other more expensive texting systems. 

