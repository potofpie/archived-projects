import pandas as pd
import csv
from twilio.rest import Client
import re
import smtplib



#=========================#
####Set up for Twillo######
#=========================#
account_sid = ""
auth_token  = ""
client = Client(account_sid, auth_token)
#=========================#


#=================================#
####Set up for email(smtplib)######
#=================================#
email = ""
username = ""
password = ""
server = smtplib.SMTP(host='smtp.gmail.com', port=587)
server.starttls()
server.login(username, password)
msg = "Test Message for the mass texting program"
#=================================#


#=================================#
######Gets numbers and FLAG########
#=================================#
def getNumbers():
    numberList = []
    with open('nums.csv', 'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
        for row in spamreader:
            row = row[0].split(",")
            numberList.append(row)
    numberList.pop(0) #First element is popped because it is the header
    return numberList
#=================================#

#===============================================#
######Uses Twillo to get email extensions########
#===============================================#
def addExtendtions(numberList):
    for num in numberList:
        number = client.lookups.phone_numbers("+" + num[0]).fetch(type="carrier")
        if (number.carrier['name']) == "AT&T Wireless":
            z = num[0] + "@txt.att.net"
        elif (number.carrier['name']) == "Verizon Wireless":
            z = num[0] + "@vtext.com"
        elif (number.carrier['name']) == "Sprint Spectrum, L.P.":
            z = num[0] + "@messaging.sprintpcs.com"
        elif (number.carrier['name']) == "T-Mobile USA, Inc.":
            z = num[0] + "@tmomail.net"
        elif (number.carrier['name']) == "U.S. Cellular ":
            z = num[0] + "@email.uscc.net"
        num.append(z)
    return numberList
#===============================================#


#===============================================#
######Uses Twillo to get email extensions########
#===============================================#
def sentEmails(numberList):
    for num in numberList:
        if num[1] == 0:
            server.sendmail(email, num[2], msg)
#===============================================#

def main():
    sentEmails(addExtendtions(getNumbers()))



if __name__ == "__main__":
    main()
