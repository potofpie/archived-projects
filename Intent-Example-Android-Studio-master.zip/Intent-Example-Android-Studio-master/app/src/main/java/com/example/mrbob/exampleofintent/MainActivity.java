package com.example.mrbob.exampleofintent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //The two elements in our xml file
        Button button = findViewById(R.id.b_0);
        final EditText editText = findViewById(R.id.et_0);

        //OnClickListener for our button
        button.setOnClickListener(new View.OnClickListener() {
            //The code in this function will run when the button is clicked
            public void onClick(View v) {

                /*
                Bellow is a Toast object. You can use these to do on device debugging when it is
                inconvenient to look at the terminal.

                Tutorial link: https://developer.android.com/guide/topics/ui/notifiers/toasts
                Docs link: https://developer.android.com/reference/android/widget/Toast
                */
                //Toast.makeText(MainActivity.this, editText.getText(), Toast.LENGTH_LONG).show();


                //In this function me pass in our current activity and the one we would like to open.
                Intent i = new Intent(MainActivity.this, ActivityTwo.class);

                /*This is were we sent information to our next activity. The name we give it is
                important when we right code to receive the information.*
                 */
                i.putExtra("info", editText.getText().toString());

                startActivity(i);
            }
        });
    }
}
