package com.example.mrbob.exampleofintent;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class ActivityTwo extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        //The two elements in our xml file
        Button button = findViewById(R.id.b_0);
        TextView tv = (TextView) findViewById(R.id.tv_0);


        //Grabs the intent object we sent to our new activity
        Intent intent = getIntent();
        //Grabs the string we gave the name "TheInfo"
        String info = intent.getStringExtra("info");
        //Sets what is stored in info to the TextView object from our xml file

        tv.setText(info);

        //OnClickListener for our button
        button.setOnClickListener(new View.OnClickListener() {
            //The code in this function will run when the button is clicked
            public void onClick(View v) {
                //finish() returns to the first activity
                finish();
            }
        });

    }

}
