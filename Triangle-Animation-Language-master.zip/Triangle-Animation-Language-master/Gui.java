import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

public class Gui extends JFrame {
	Tal tal;


	public Gui(String[] instructs) {
		tal = new Tal(instructs);

		try
		{
      tal.img = ImageIO.read(new File("./background.png"));
		}



		catch (IOException e)
		{
			System.out.printf("img open failed\n");
			e.printStackTrace();
			System.exit(1);
		}
		tal.setSize(tal.img.getWidth(), tal.img.getHeight());
		setBackground(Color.MAGENTA);
		this.add(tal);
	}
}
