import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

class MGui {

//RandomAccessFile raf = new RandomAccessFile(file, "rw");

	public static void main(String[] args) {
		String fn;
		File f;
		FileReader fr;
		RandomAccessFile raf;
		String line;
		String[] instructList;
		JFrame bframe;
		if(args.length == 0)
		{
			System.out.println("MGui | args[0] = 'filename'");
			System.exit(0);
		}

		fn=args[0];
		f=new File(fn);

		try{
			int instructLength = 0;
			raf = new RandomAccessFile(f, "rw");

			while (raf.readLine() != null) //count how many lines are in instructions
			{
				++instructLength;
			}

			instructList = new String[instructLength]; //init array with proper amount
			raf.seek(0); //reset RandomAccessFile to begining for file
			//System.out.println(instructLength);

			for(int i = 0; i < instructLength; i++){
				instructList[i] = raf.readLine();
			}

			bframe = new Gui(instructList);
			bframe.setLocation(32,32);
			bframe.setSize(500,500);
			bframe.setVisible(true);
			bframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		catch (IOException e) {
			System.out.println(e);
			System.exit(0);
		}



	}

}
