# Triangle-Animation-Language
## Instructions
To run the program type java MGui instructions. 

## Editing the Instructions File
The first line is for the inital size of the triangle.<br/> 
Ex: x1 y1 x2 y2 x3 y3 <br/>

Translate x y - T 0 2 <br/>
Scale x y - S 1.1 0.9 <br/>
Rotate float - R 0.1
