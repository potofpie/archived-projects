import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.geom.*;
import java.awt.event.*;
import javax.imageio.*;
import javax.swing.Timer;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class Tal extends JPanel{
  BufferedImage img=null;
  Graphics2D g2d;
  static String instructs[];
  Triangle t, reset;
  Timer timer;
  int count = 1;
  public Tal(String[] x)
  {
    instructs = x;
    String[] splited = instructs[0].split("\\s+");
    int[] tmpPointArray = new int[splited.length];
    try{
      for(int i = 0; i < splited.length; i++)
      {
        tmpPointArray[i] = Integer.parseInt(splited[i]);
      }
      reset = new Triangle(tmpPointArray);
      t = new Triangle(tmpPointArray);
    }
    catch(Exception e){
      System.out.println(e);
      System.exit(0);
    }
    //All this sets up a triangle ^^^^
    refreshScreen();
  }

  public synchronized void paintComponent(Graphics g)
  {
      g2d = (Graphics2D) g;
      g2d.clearRect(0, 0, 500, 500);
      g2d.setColor(Color.YELLOW);

      g2d.drawLine(t.p0.x,t.p0.y,  t.p1.x,t.p1.y  );
      g2d.drawLine(t.p1.x,t.p1.y, t.p2.x,t.p2.y   );
      g2d.drawLine(t.p2.x,t.p2.y, t.p0.x,t.p0.y   );

  }

//http://www.java2s.com/Tutorials/Java/Swing_How_to/Timer/Refresh_with_swing_Timer.htm
  public void refreshScreen() {
    timer = new Timer(0, new ActionListener() {
        int i = 1;
      @Override
      public void actionPerformed(ActionEvent e) {
        repaint();
        String[] c = instructs[i].split("\\s+");
        System.out.println(instructs[i]);
        if(c[0].equals("T"))
        {
            t.translate(Integer.parseInt(c[1]), Integer.parseInt(c[2]));
        }
        else if(c[0].equals("S"))
        {
            t.scale(Float.parseFloat(c[1]), Float.parseFloat(c[2]));
        }
        else if(c[0].equals("R"))
        {
            t.rotate(Float.parseFloat(c[1]));
        }
        i++;
        if(i >= instructs.length){

            System.out.println("reset");
            t = reset;
            i = 1;
        }
      }
    });
    timer.setRepeats(true);
    timer.setDelay(100);
    timer.start();

  }
//http://www.java2s.com/Tutorials/Java/Swing_How_to/Timer/Refresh_with_swing_Timer.htm



    //These are two in line classes that hold my points repersenting my triangle //
    public class Triangle{
      Point p0;
      Point p1;
      Point p2;
      Point[] ps = new Point[3];
     public Triangle(int[] points)
     {
        p0 = ps[0] = new Point(points[0], points[1]);
        p1 = ps[1] = new Point(points[2], points[3]);
        p2 = ps[2] = new Point(points[4], points[5]);
     }
     public void translate(int x, int y)
     {
         p0.x = p0.x + x;
         p1.x = p1.x + x;
         p2.x = p2.x + x;
         p0.y = p0.y + y;
         p1.y = p1.y + y;
         p2.y = p2.y + y;
     }
     public void scale(float x, float y)
     {
       int dx = (p0.x + p1.x + p2.x)/3;
       int dy = (p0.y + p1.y + p2.y)/3;

       p0.x = dx+(int)((p0.x - dx)*x);
       p0.y = dy+(int)((p0.y - dy)*y);

       p1.x = dx+(int)((p1.x - dx)*x);
       p1.y = dy+(int)((p1.y - dy)*y);

       p2.x = dx+(int)((p2.x - dx)*x);
       p2.y = dy+(int)((p2.y - dy)*y);

     }
     public void rotate(float da)
     {
         p0.x = (int)((p0.x*Math.cos(da))) - (int)((p0.y*Math.sin(da))) ;
         p0.y = (int)((p0.x*Math.sin(da))) + (int)((p0.y*Math.cos(da))) ;

         p1.x = (int)((p1.x*Math.cos(da))) - (int)((p1.y*Math.sin(da))) ;
         p1.y = (int)((p1.x*Math.sin(da))) + (int)((p1.y*Math.cos(da))) ;

         p2.x = (int)((p2.x*Math.cos(da))) - (int)((p2.y*Math.sin(da))) ;
         p2.y = (int)((p2.x*Math.sin(da))) + (int)((p2.y*Math.cos(da))) ;
     }
     public class Point{
       int x;
       int y;
      public Point(int i, int j)
      {
        x = i;
        y = j;
      }
   }
  }
}
