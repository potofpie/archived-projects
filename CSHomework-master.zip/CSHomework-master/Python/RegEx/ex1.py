import re
#\s means space
#\d means digits
#\w means letters or numbers
#capital of anything mean the opposite mean EX: \D means anything but digits
#quantites * 0 or more; + 1 or more; ? 0 or 1; {5}{1-60} range or exact
#. means anything but a new line character

print(re.split(r'\s*', 'he\nre are\n \nsome words\n')) #splits on space
print(re.split(r'(\s*)', 'here are some words')) #splits on space includes space in array
print(re.split(r'(s*)', 'here are some words')) #splits on s

print(re.split(r'[a-f]', 'jksdnhFGDFGFfjlk;sdajflk;GHFDJHGKKjsadlk;k;lKLJ;JKL;JKadsnvk;ln'))
#splits on the things in range no include NO UPPERCASE^^^

print(re.split(r'[a-fA-F]', 'jksdnhFGDFGFfjlk;sdajflk;GHFDJHGKKjsadlk;k;lKLJ;JKL;JKadsnvk;ln', re.I|re.M))
#includes multilins

print(re.split(r'[a-f][a-f]','xyzabqrsat'))
#splits on both ranges next to one another

print(re.findall(r'\d{1,5}\s\w+\s\w+\.','ldkdfdsfs324 main st.asdvc'))
