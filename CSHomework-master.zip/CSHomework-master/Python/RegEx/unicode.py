import sys
import re
raw = '🔧 🐲 👌 🚗 ✋ 🚗 <var>'
valid = 'junk'
#['🔧', "<funct>"],['', 🐲],["😄", <var>],"😆",<var>]]
#print(re.findall(r'[bobby][bob][robert]', b))
valid = re.findall(r'^[🔧][🐲]', raw)
raw = re.sub(r'^[🔧][🐲]', raw)
print (len(valid))
if len(valid) == 2 :
    valid.extend(re.findall(r'^[👌][🚗🚗⛵❔📄📖]', raw))
    if ((len(valid)) in (2,4)):
            print(valid)
    else:
        sin()
else:
    sin()
def sin():
    print("you have committed a syntax sin")
    quit()
#[✋[[🚗<var>]*[🚗<var>]*[⛵<var>]*[❔<var>]*[📄<var>]*[📖<var>]*]+]*
