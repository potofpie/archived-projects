
import java.io.*;

public class InfoPack implements Serializable{
     static int[] corts = new int[2];
     public InfoPack() {
          corts[0] = 0;
          corts[1] = 0;
     }
     public static int[] getCorts(){
          return corts;
     }
     public static void getCorts(int[] in){
          corts = in;
     }

}
