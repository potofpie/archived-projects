import javax.swing.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.Color;
import java.net.*;
import java.io.*;

public class DrawCircle extends JFrame {

public static JLabel l0;
public static JLabel l1;
public static int x;
public static int y;
     public static class SocketThread extends Thread {
          String[] str;
          public SocketThread(String[] args) {
               str = args;
               System.out.println("Created constuctor");
          }
          public void run() {
               System.out.println("Thread started");
               try{
                    if (Integer.parseInt(str[0]) == 1){
                         ServerSocket ss = new ServerSocket(Integer.parseInt(str[1]));
                         System.out.println("Waiting for Connection");
                         Socket s = ss.accept();
                         System.out.println("Connected");
                         l0.setBounds(100,100,9,9);
                         OutputStream os = new OutputStream(s.getOutputStream());
                         //ObjectInputStream is = new ObjectInputStream(s.getInputStream());
                         int[] outputCort = new int[2];
                         //int[] inputCort = new int[2];
                         while(true){
                              outputCort[0] = x;
                              outputCort[1] = y;
                              InfoPack ip = new InfoPack();
                              ip.setCorts(outputCort);
                              os.writeObject(ip);
                              System.out.println("SENT ||| X:"+ x + " | " + "Y: " + y);
                              //ip = is.readObject();
                              //inputCort = ip.getCorts();
                              //System.out.println("Blue:" + inputCort[0] + inputCort[1]);
                              //l1.setBounds(inputCort[0],inputCort[1],9,9);
                         }
                    }//Server
                    if (Integer.parseInt(str[0]) == 0){
                         System.out.println("Making connection");
                         Socket s = new Socket(str[1], Integer.parseInt(str[2]));
                         System.out.println("Connected");
                         l0.setBounds(100,100,9,9);
                         //ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                         System.out.println("Create ObjectInputStream");
                         InputStream is = new InputStream(s.getInputStream());
                         //int[] outputCort = new int[2];
                         int[] inputCort = new int[2];
                         InfoPack ip = new InfoPack();
                         System.out.println("Enter while");
                         while(true){
                              //outputCort[0] = x;
                              //outputCort[1] = y;
                              //ip.setCorts(outputCort);
                              //os.writeObject(ip);
                              ip = is.readObject();
                              inputCort = ip.getCorts();
                              System.out.println("Recived ||| X:"+ inputCort[0] + " | " + "Y: " + inputCort[1]);
                              l1.setBounds(inputCort[0],inputCort[1],9,9);
                         }
                    }//Client
               }
               catch(IOException e) {
                    System.out.println(e);
               }
          }
     }
public static void main(String[] args) {
     l0 = new JLabel("0");
     l0.setBounds(200,100,200,40);
     l0.setForeground(Color.RED);

     l1 = new JLabel("0");
     l1.setBounds(200,200,9,9);
     l1.setForeground(Color.BLUE);

     JFrame.setDefaultLookAndFeelDecorated(true);
     JFrame f= new JFrame("Get X and Y coordinates");
     f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     f.getContentPane().add(l0);
     f.getContentPane().add(l1);
     f.setSize(300,300);
     f.setLayout(null);
     f.setVisible(true);
     SocketThread st = new SocketThread(args);
     Thread t1 = new Thread(st);
     t1.start();

     f.addMouseListener(new MouseListener() {
          public void mousePressed(MouseEvent me) {
               x = me.getX();
               y = me.getY();
               l0.setBounds(x,y,9,9);
               System.out.println("X:"+ x + " | " + "Y: " + y);
          }
          public void mouseReleased(MouseEvent me) { }
          public void mouseEntered(MouseEvent me) { }
          public void mouseExited(MouseEvent me) { }
          public void mouseClicked(MouseEvent me) {}
          });
    }

}
