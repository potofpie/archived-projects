import java.net.*;
import java.io.*;

public class HelloWorld {
    public static void main(String[] args) {
	int PORT = 8899;
	String IP = 172.16.201.200;

	try{
        Socket s = new Socket("172.16.201.200", 8899);
	}
	catch (IOException e) {
	System.err.println("Caught IOException: " + e.getMessage());
	}
	}


}
