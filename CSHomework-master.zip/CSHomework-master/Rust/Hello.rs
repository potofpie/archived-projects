#[allow(non_snake_case)]
fn main() {
	let Pi = format!("{:.*}",4 ,3.141592);
	print!("Pi is about {}", Pi );
}


let port = 9999

pub const PI: f64 = 3.14159265358979323846264338327950288f64

let x = 1;

println!("{} is at location {:p}", x, &x);

1 is at location 0x7fff39642cf4


macro_rules! foo {
    (x => $e:expr) => (println!("mode X: {}", $e));
    (y => $e:expr) => (println!("mode Y: {}", $e));
}

fn main() {
    foo!(y => 3);
}


fn main() {
	let x = 6;
		print!("{}", x);
		{
			let x = 10
			print!("{}", x);
		}
	print!("{}", x);
    }

6106

There are 2 1s


fn rotate_right(self, n: u32) -> i8

fn rotate_left(self, n: u32) -> i8

fn swap_bytes(self) -> i8


loop{
	println!("hey!");
	input = read!();
	if input == "what!?"{
		break;
	}
}
