fn main(){
let mut x = 5;
println!("x is at {:p}", &x);
println!("x is at {}", x);
x = 6;
println!("x is at {:p}", &x);
println!("x is at {}", x);
}
