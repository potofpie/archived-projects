extern crate rand;

use rand::{thread_rng, Rng};

fn main(){
    let mut randNums: [i32; 1000] = randArray();
    let  mut temp;
    let len = randNums.len();

    for _ in 0..len{
        for x in 0..len-1{
            if randNums[x] < randNums[x+1]{
                temp = randNums[x+1];
                randNums[x+1] = randNums[x];
                randNums[x] = temp;
            }
        }
    }
    println!("After:");
    for x in 0..1000 {
        print!("{}", randNums[x]); // x: i32
    }
}

fn randArray() -> [i32; 1000] {
    let mut rng = thread_rng();
    let mut array: [i32; 1000] = [0; 1000];
    println!("Before:");
    for x in 0..1000 {
        array[x] = rng.gen_range(0, 100);
        print!("{}", array[x]); // x: i32
    }
    return array;
}
