import re
import os, sys

f = open("lastNames","r")
nf = open("workfile","w")
wordList = re.split(r'\s', f.read())
wlLength = len(wordList)

newWords=[];

def StringtoList(word):
    print "word in fn: ", word
    wordToList = []
    for letter in word:
        wordToList.append(letter)
    return wordToList

for word in range(wlLength):
    t = wordList[word]
    tLength = len(t)
    print(tLength)
    tmp =  StringtoList(t)
    print(tmp)
    print(len(tmp))
    for letter in range(1, tLength):
        print(tmp[letter])
        print(chr(ord(tmp[letter]) + 32))
        tmp[letter] = chr(ord(t[letter]) + 32)
    wordList[word] = ''.join(tmp)

for word in range(wlLength):
    nf.write(wordList[word] + "\n")
