

raw = ["🔧", "🐲","👌","🚗"]

codeblock = True

def program():
    if(True == function(raw)):
        print("right")
        return True
    else:
        print("error")
        return False


def function(data):
	if(data.pop(0) == "🔧"):
		if(data.pop(0) == "🐲"):
			if(True == optional(data)):
				print("right")
				return True
			else:
				print("error")
				return False
		else:
			print("error")
			return False
	else:
		print("error")
		return False

def optional(data):
	if(True == parameter(data)):
		return True


def parameter(data):
	if(data.pop(0) == "👌"):
		if(True == isTypeSpecifier(data)):
			return True
		else:
			
	
	else:
		return True
	


def isTypeSpecifier(data):
	if(data.pop(0) == "🚗"):
		return True
	elif(data.pop(0) == "🚚"):
		return True
	elif(data.pop(0) == "⛵"):
		return True
	elif(data.pop(0) == "📄"):
		return True
	elif(data.pop(0) == "📖"):
		return True
	else:
		return False

program()
