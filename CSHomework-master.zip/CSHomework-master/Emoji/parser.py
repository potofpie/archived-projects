
rules = {}

terminal = {}

terminal["🌏"] = non = {}
terminal["🌍"] = non = {}
terminal["🐲"] = non = {}
terminal["🔧"] = non = {}
terminal["👌"] = non = {}
terminal["✋"] = non = {}
terminal["🏃"] = non = {}
terminal["🍭"] = non = {}
terminal["🐶"] = non = {}
terminal["🐱"] = non = {}
terminal["<assignment-operator>"] = non = {}
terminal["<type-specifier>"] = non = {}
terminal["<conditional-symbol>"] = non = {}
terminal["<math-operator>"] = non = {}
terminal["<var>"] = non = {}
terminal["<int-constant>"] = non = {}
terminal["<float-constant>"] = non = {}
terminal["<string-constant>"] = non = {}
terminal["<char-constant>"] = non = {}

#"<function>" -> ["🔧", "🐲", ]

#assignment
rules.append('1', rule["<var>", "<assignment-operator>", "<math-expression>", "🏃"])
#math-expression
rules.append('2', rule["<conditional-expression>"])
rules.append('2', rule["<var>", "<assignment-operator>", "<conditional-expression>", "🏃"])



#<assignment-statement> -> <var> <assignment-operator> <constant> 🏃

terminal.get("<var>").append("<assignment-statement>", '1')
