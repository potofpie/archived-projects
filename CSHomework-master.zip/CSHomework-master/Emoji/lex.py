import sys
import re

#get list raw
f0 = open(sys.argv[1], 'r')
raw = f0.read()
print(raw)
split = str.split(raw)
print(split)

dict = {}
dict["🌏"] = "🌏"
dict["🌍"] = "🌍"
dict["🐲"] = "🐲"
dict["🔧"] = "🔧"
dict["👌"] = "👌"
dict["✋"] = "✋"
dict["🏃"] = "🏃"
dict["🍭"] = "🍭"
dict["🐶"] = "🐶"
dict["🐱"] = "🐱"
dict["✊"] = "<assignment-operator>"
dict["🚗"] = "<type-specifier>"
dict["🚚"] = "<type-specifier>"
dict["⛵"] = "<type-specifier>"
dict["❔"] = "<type-specifier>"
dict["📄"] = "<type-specifier>"
dict["📖"] = "<type-specifier>"
dict["📖"] = "<type-specifier>"
dict["🚑"] = "<conditional-symbol>"
dict["👼"] = "<conditional-symbol>"
dict["👭"] = "<conditional-symbol>"
dict["👬"] = "<conditional-symbol>"
dict["🌜"] = "<conditional-symbol>"
dict["🌛"] = "<conditional-symbol>"
dict["🐰"] = "<math-operator>"
dict["👍"] = "<math-operator>"
dict["👎"] = "<math-operator>"
dict["🐊"] = "<math-operator>"
dict["👂"] = "<math-operator>"
for x in range(0,50):
    emoj = chr(0x0001f600+x)
    dict.update({emoj:"<var>"})

lexedlist = []

for x in range(0, len(split)):
    if split[x] in dict: lexedlist.append( (dict.get(split[x]), split[x]) )
    elif re.findall(r'^[0-9]+$', split[x]): lexedlist.append( ("<int>", split[x]) )
    elif re.findall(r'^[0-9]*[.]?[0-9]+$', split[x]): lexedlist.append( ("<float>", split[x]) )
    elif re.findall(r'^".*"$', split[x]): lexedlist.append( ("<string>", split[x]) )
    elif re.findall(r'^\'.\'$', split[x]): lexedlist.append( ("<char>", split[x]) )
    else:
        print(split[x])
        print("Error\n \"", split[x], "\" not recognized as token")
        quit()

    

print (lexedlist)
