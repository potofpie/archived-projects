#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/time.h>

#define PORT 8899
#define BUFF_SIZE 1024

#define T_DIFF(t1,t0)		((double)(t1.tv_sec-t0.tv_sec)+((double)(t1.tv_usec-t0.tv_usec)/1000000))

int waitfor(port)
int port;
{
        int lfd = 0, cfd = 0;
        struct sockaddr_in serv_addr;
        char buf[BUFF_SIZE];

        lfd = socket(AF_INET, SOCK_STREAM, 0);
        memset(&serv_addr, '0', sizeof(serv_addr));
        memset(buf, '0', sizeof(buf));

        serv_addr.sin_family = AF_INET;
        serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        serv_addr.sin_port = htons(port);

        bind(lfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

        listen(lfd, 10);

        cfd = accept(lfd, (struct sockaddr*)NULL, NULL);
        return(cfd);
}

void main(){
	double final;
	struct timeval start, diff;
	int f;
	int s;
	char buf[BUFF_SIZE];
	//f = open("/home/landmark/Desktop/nasaPlanetData.45", O_RDONLY);
	f = open("./nasaPlanetData.456", O_CREAT|O_WRONLY|O_TRUNC, 0664);
	int i;
	int check = 0;

	printf("Waiting for Connection\n");
	s = waitfor(PORT);
	printf("Connected\n");
	gettimeofday(&start, 0);
		while(1){

		i = read(s, buf, BUFF_SIZE);
			if(i > 0){
				write(f, buf, i);
			}
			else{
				gettimeofday(&diff, 0);
				break;
			}
		}
		final = T_DIFF(diff, start);
		printf("%lf, %d",final, check);
	}
