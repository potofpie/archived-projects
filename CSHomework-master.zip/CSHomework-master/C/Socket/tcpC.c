#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/time.h>

#define PORT 8899
#define BUFF_SIZE 1024
//#define IP  "172.16.52.65"
#define IP  "1ocalhost"
#define T_DIFF(t1,t0)		((double)(t1.tv_sec-t0.tv_sec)+((double)(t1.tv_usec-t0.tv_usec)/1000000))

void main(){
	double final;
	struct timeval start, diff;
	int f;
	int s;
	char buf[BUFF_SIZE];
	//f = open("/var/www/cs2751/assignments/nasaPlanetData.45", O_RDONLY);
	f = open("./nasaPlanetData.45", O_RDONLY);
	int i;
	int check = 0;



	struct sockaddr_in dest;

	s = socket(AF_INET, SOCK_STREAM, 0);
	bzero(&dest, sizeof(dest));
	dest.sin_family = AF_INET;
	dest.sin_port = htons(PORT);
	inet_aton(IP, (struct in_addr *) &dest.sin_addr.s_addr);
	connect(s, (struct sockaddr*)&dest, sizeof(dest));

	gettimeofday(&start, 0);
	while(1){
			i = read(f, buf, BUFF_SIZE);
			if(i > 0){
				write(s, buf, BUFF_SIZE);
			}
			else{
				gettimeofday(&diff, 0);
				break;
			}
	}
		final = T_DIFF(diff, start);
		printf("%lf, %d",final, check);
	}
