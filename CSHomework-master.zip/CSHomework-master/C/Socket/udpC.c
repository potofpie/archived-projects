#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/time.h>
#define HOST "localhost"
#define PORT 25565
#define BUFF_SIZE 1024
#define T_DIFF(t1,t0)		((double)(t1.tv_sec-t0.tv_sec)+((double)(t1.tv_usec-t0.tv_usec)/1000000))



int main(){
struct hostent *hp; /* host information */
struct sockaddr_in servaddr; /* server address */
const char *m = "this is an important thing"; /* fill in the server's address and data */
int fd;
int f;
int i;
char buf[BUFF_SIZE];

f = open("./nasaPlanetData.45", O_RDONLY);

     if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
          {
               perror("cannot create socket\n");
               return 0;
          }

//printf("%s", m);
memset((char*)&servaddr, 0, sizeof(servaddr));
servaddr.sin_family = AF_INET;
servaddr.sin_port = htons(PORT); /* look up the address of the server given its name */
servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");


     while(1){
          i = read(f, buf, BUFF_SIZE);
          if(i > 0){
               if ((sendto(fd, buf, i, 0, (struct sockaddr *)&servaddr, sizeof(servaddr))) < 0)
               {
                    perror("sendto failed");
                    return 0;
               }
          }
          else{
               break;
          }
     }
}
