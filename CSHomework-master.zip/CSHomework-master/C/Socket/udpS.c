#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/time.h>
#define PORT 25565
#define BUFSIZE 1024
#define T_DIFF(t1,t0)		((double)(t1.tv_sec-t0.tv_sec)+((double)(t1.tv_usec-t0.tv_usec)/1000000))

int main(){
struct sockaddr_in myaddr;
struct sockaddr_in remaddr;
socklen_t addrlen = sizeof(remaddr);
int recvlen;
int fd;
int f;
unsigned char buf[BUFSIZE];
f = open("./nasaPlanetData.456", O_CREAT|O_WRONLY|O_TRUNC, 0664);

     if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
          {
               perror("cannot create socket\n");
               return 0;
          }

memset((char *)&myaddr, 0, sizeof(myaddr));
myaddr.sin_family = AF_INET;
myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
myaddr.sin_port = htons(PORT);

     if (bind(fd, (struct sockaddr *)&myaddr, sizeof(myaddr)) < 0)
          {
               perror("bind failed");
               return 0;
          }
     while(1)
     {
          //printf("waiting on port %d\n", PORT);
          //printf("1Looking...");
          recvlen = recvfrom(fd, buf, BUFSIZE, 0, (struct sockaddr *)&remaddr, &addrlen);
          //printf("received %d bytes\n", recvlen);
          //printf("2Looking...");
               if (recvlen > 0)
               {
                    //printf("Length: %d\n", recvlen );
                    write(f, buf, recvlen);
                    //printf("3Looking...");
                    buf[recvlen] = 0;
                    //printf("4Looking...");
               }
               else{
                    printf("Length: 0");
                    break;
               }
          //printf("5Looking...");
     }


}
