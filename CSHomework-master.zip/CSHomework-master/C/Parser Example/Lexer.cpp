#include "Lexer.h"
#include <stdlib.h>

// Main to test the Lexer

int main(void) {
	Lexer lexer; // create a lexer object
	int token;
	if (lexer.openFile()) {
       lexer.getChar();
	   do {
		  token = lexer.lex();
	   } while (token != EOF);
	}
}

Lexer::Lexer(void)
{
	fillSpecialWords();
}

Lexer::~Lexer(void)
{
	closeFile();
}

// ******************************************************************************************
// Open File
// ******************************************************************************************
bool Lexer::openFile() {
    file.open("input.txt");
    if (!file.is_open()) {
	printf("ERROR - cannot open input.txt \n");
	return false;
    }
    return true;
}

// *******************************************************************************************
// CLOSE FILE
// *******************************************************************************************
void Lexer::closeFile() {
	file.close();
	system("pause"); ///debug testing purposes
}

// *******************************************************************************************
// FILL SPECIAL WORDS
// *******************************************************************************************
void Lexer::fillSpecialWords() {
	cout << "About to fill special words map\n";

	specialWord[string("Scalpel")] = 14;
	specialWord[string("Cannondale")] = 15;
	specialWord[string("Pivot")] = 16;
	specialWord[string("elbow")] = 17;
	specialWord[string("knee")] = 18;
	specialWord[string("hip")]= 19;
	specialWord[string("shoulder")] = 20;
	specialWord[string("ankle")] = 21;
	specialWord[string("head")] = 22;
	specialWord[string("leg")] = 23;
	specialWord[string("tire")] = 30;
	specialWord[string("wheel")] = 31;
	specialWord[string("derailleur")] = 32;
	specialWord[string("chain")] = 33;
        specialWord[string("also")] = 40;
	specialWord[string("My_new_ride_is")] = 41;
	specialWord[string("then")] = 42;
	specialWord[string("Rode_at")] = 43;
	specialWord[string("on")] = 44;
	specialWord[string("Tried")] = 45;

	specialWord[string("hurt_my")] = 50;
	specialWord[string("broke_my")] = 51;
	specialWord[string("now_I_need_my")] = 52;
	specialWord[string("fixed")] = 53;

	specialWord[string("Willowdale")] = 60;
	specialWord[string("Fells")] = 61;
	specialWord[string("LDT")] = 62;
	specialWord[string("RM")] = 63;
	specialWord[string("HP")] = 64;
	specialWord[string("LLF")] = 65;

	specialWord[string("Monday")] = 70;
	specialWord[string("Tuesday")] = 71;
	specialWord[string("Wednesday")] = 73;
	specialWord[string("Thursday")] = 74;
	specialWord[string("Friday")] = 75;
	specialWord[string("Saturday")] = 76;
	specialWord[string("Sunday")] = 77;
}

// *******************************************************************************************
// LOOKUP
// returns the appropriate token to single-char operators (and defines it as its own lexeme)
// *******************************************************************************************
int Lexer::lookup(char ch) {
	switch (ch) { //calls file.unget() when looking ahead for more than one character but there isn't one, so everything stays consistent
		case '.':
			addChar();
			nextToken = PERIOD;
			break;
		case '!':
			addChar();
			nextToken = EXCLAMATION;
			break;
		case ',':
			addChar();
			nextToken = COMMA;
			break;
		case '_':
			addChar();
			nextToken = UNDERSCORE;
			break;
		default:
			addChar();
			nextToken = EOF;
			break;
	}
	return nextToken;
}

// *******************************************************************************************
// ADDCHAR
//    adds nextChar to the lexeme
// *******************************************************************************************

void Lexer::addChar() {
	if (lexLen <= 98) {
		//cout << "Character " << nextChar << " placed at index " << lexLen << "\n";
		lexeme[lexLen++] = nextChar;
		lexeme[lexLen] = 0;
	}
	else
		printf("Error - lexeme is too long \n");
}


// *******************************************************************************************
// GETCHAR
//    gets next char and returns its character class\
// *******************************************************************************************

void Lexer::getChar() {

	if (file.good()) {
		nextChar = file.get();
		//cout << "Next character:" << nextChar << "|" << endl;

		if (isalpha(nextChar))
			charClass = LETTER;
		else if (isdigit(nextChar))
			charClass = DIGIT;
		else if (nextChar == '_')
			charClass = UNDERSCORE;
		else
			charClass = UNKNOWN;
	}
	else {
            cout << "End of file reached.\n";
	 charClass = EOF;
        }
}

// *******************************************************************************************
//just skips whitespace
// *******************************************************************************************
void Lexer::getNonBlank() {
    while (isspace(nextChar) && (charClass != EOF))
	getChar();
}


// *******************************************************************************************
// Reads in next lexemes and returns its associated token
// *******************************************************************************************
int Lexer::lex() {
	cout << "LEX\n";

	lexLen = 0;
	getNonBlank();	// Eat up white space

	switch (charClass) {
		//parse identifiers
		case LETTER:
			addChar();
			getChar();
			while (charClass == LETTER || charClass == DIGIT || charClass == UNDERSCORE) {
				addChar();
				getChar();
			}
			nextToken = specialWord[string(lexeme)];
			break;

		//parse ints
		case DIGIT:
			addChar();
			getChar();
			while (charClass == DIGIT) {
				addChar();
				getChar();
			}
			nextToken = INT_LIT;
			break;

		// Single characters
		case UNKNOWN:
			lookup(nextChar);
			getChar();
			break;

		case EOF:
			nextToken = EOF;
			lexeme[0] = 'E';
			lexeme[1] = 'O';
			lexeme[2] = 'F';
			lexeme[3] = 0;
			break;
	} //end of switch

	printf("lexeme: %s \n",lexeme);
	return nextToken;
}
