This C++ illustration based on an EBNF definition of an LL(1) grammar was developed quickly in order to get a simple working illustration out to students.  There are many improvements that could be made, among them:

1. Read in the input file name from the user
2. Complete the syntax analyzer with all of the grammer
3. Make some terminal symbols identifiers (brand, name, bike parts, body parts, etc,...) to allow extensibility
4. Remove some of the redundancy in the code
5. Make it actually behave as an analogy to a programming language (as your project is meant to do). 

If you would like extra credit toward the end of the semester or if you would like to earn some work study money please see me about improving the project for future classes.

Thanks.