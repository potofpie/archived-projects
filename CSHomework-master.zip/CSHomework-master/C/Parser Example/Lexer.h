#pragma once

#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <map>

#define IDENT 0
#define LETTER 1
#define DIGIT 2
#define UNDERSCORE 3
#define INT_LIT 4
#define PERIOD 5
#define EXCLAMATION 6
#define COMMA 7
#define Scalpel  14 
	#define Cannondale  15 
	#define Pivot  16 
	#define elbow  17 
	#define knee  18 
	#define hip 19
	#define shoulder  20 
	#define ankle  21 
	#define head  22 
	#define leg  23 
	#define tire  30 
	#define wheel  31 
	#define derailleur  32 
	#define chain  33 
        #define also 40 
	#define My_new_ride_is  41 
	#define then  42 
	#define Rode_at  43 
	#define on  44 
	#define Tried  45 

	#define hurt_my  50 
	#define broke_my  51 
	#define now_I_need_my  52 
	#define fixed  53 

	#define Willowdale  60 
	#define Fells  61 
	#define LDT  62 
	#define RM  63 
	#define HP  64 
	#define LLF  65 

	#define Monday  70 
	#define Tuesday  71 
	#define Wednesday  73 
	#define Thursday  74 
	#define Friday  75 
	#define Saturday  76 
	#define Sunday  77 


#define UNKNOWN 99

using namespace std;


class Lexer
{
	int charClass;
	char lexeme[100];
	char nextChar;
	int lexLen;
	int token;
	int nextToken;
	ifstream file;
	map<string,int> specialWord; 

	public:
		Lexer(void);
		~Lexer(void);

		//Method declarations
		void addChar();
		void getChar();
		void getNonBlank();
		bool openFile();
		void closeFile();
		void fillSpecialWords();
		int lex();
		int lookup(char ch);



};

