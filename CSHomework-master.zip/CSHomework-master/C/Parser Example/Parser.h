#pragma once
#include "Lexer.h"

class Parser
{
	Lexer lexer;
	int nextToken;

public:
	Parser(void);
	~Parser(void);

	void mountain_biking(void);
	void brand(void);
	void name(void);
	void body_part(void);
	void bike_part(void);

	void buy_bike(void);
	void demo_bikes(void);
	void demo(void);
	void select_bike(void);
	void riding(void);
	void rode(void);
	void repair(void);
	void location(void);
	void day_of_week(void);
        
        bool success;
};


