#include "Parser.h"

// ***************************************************************
// Main to test the parser
// ***************************************************************
int main(void) {
    Parser parser; // create a parser object
}

// ***************************************************************
// Constructor
// ***************************************************************
Parser::Parser(void)
{
    success = true;
    if (lexer.openFile()) {
       lexer.getChar();
	   nextToken = lexer.lex();
	   cout << "First token is: " << nextToken << "\n";

	   mountain_biking(); // Call start symbol

	}
    else
        success = false;
    if (success)
        cout << "Compiled correctly!\n";

}


Parser::~Parser(void)
{
}

// ************************************************************************
//  <Mountain biking> --> <buy bike> <riding>
// ************************************************************************
void Parser::mountain_biking(void) {
	cout << "mountain biking" << endl;
	buy_bike();
	riding();
        if (nextToken !=EOF) {
            success = false;
            cout << "Expected end of program\n";
        }
}

// ************************************************************************
// <brand> --> Cannondale  | Pivot
// ************************************************************************
void Parser::brand(void) {
    cout << "brand" << endl;
	if (nextToken == Cannondale || nextToken == Pivot)
		nextToken = lexer.lex();
	else {
            success = false;
            cout << "Error in brand\n";
        }
}

// ************************************************************************
// <name> -->  Scalpel
// ************************************************************************
void Parser::name(void){
    cout << "name" << endl;
	if (nextToken == Scalpel)
		nextToken = lexer.lex();
	else {
            success = false;
            cout << "Error in name\n";
        }
}

// ************************************************************************
//  <body part> --> elbow | shoulder
// ************************************************************************
void Parser::body_part(void){
    cout << "name" << endl;

	if (nextToken == elbow || nextToken == shoulder)
		nextToken = lexer.lex();
	else {
            success = false;
            cout << "Error in body part\n";
        }
}

// ************************************************************************
//  <bike part> --> tire | wheel | derailleur | chain | drivetrain | cables | crankset
// ************************************************************************
void Parser::bike_part(void){
    cout << "bike_part" << endl;
	if (nextToken == tire || nextToken == wheel)
		nextToken = lexer.lex();
	else{
            success = false;
            cout << "Error in bike part\n";
        }
}

// ************************************************************************
//  <buy_bike> -> <demo bikes> <select bike>
// ************************************************************************
void Parser::buy_bike(void){
	cout << "buy bike"  << endl;
	demo_bikes();
	select_bike();
}

// ************************************************************************
//   <demo bikes> --> <demo> {  and  <demo bikes>} .
// ************************************************************************
void Parser::demo_bikes(void){
	cout << "demo bike"  << endl;
	demo();
	while (nextToken == also) {
            nextToken = lexer.lex();
            demo();
        }
}

// ************************************************************************
// <demo> -->  Tried <brand> <name>.
// ************************************************************************
void Parser::demo(void){
  cout << "demo"  << endl;
  if (nextToken == Tried) {
	  nextToken = lexer.lex();
	  brand();
	  name();
	  if (nextToken == PERIOD)
		   nextToken = lexer.lex();
	  else {
            success = false;
            cout << "Error in demo : expecting a period";
          }
  }
  else {
         success = false;
	 cout << "Error in demo : expecting Tried";
  }
}

// ************************************************************************
//  <select_bike> --> My_new_ride_is <brand> <name> !
// ************************************************************************
void Parser::select_bike(void){
   cout << "select bike"  << endl;

   if (nextToken == My_new_ride_is) {
	  nextToken = lexer.lex();
	  brand();
	  name();
	  if (nextToken == EXCLAMATION)
            nextToken = lexer.lex();
	  else{
            success = false;
            cout << "Error in select bike: expecting ! ";
          }
    }
    else {
        success = false;
        cout << "Error in select bike: expecting My_new_ride_is";
    }
}

// ************************************************************************
//  <riding> --> <rode> [ <repair>] { then  <rode> }  .
// ************************************************************************
void Parser::riding(void){
    cout << "riding"  << endl;

    rode();

    // Still missing optional repair

    while (nextToken == then) {
	nextToken = lexer.lex();
	rode();
    }
    if (nextToken == PERIOD)
        nextToken = lexer.lex();
    else {
            success = false;
            cout << "Error in riding: expecting period";
    }
}

// ************************************************************************
// <rode>--> Road_at <location> on <day of week> [hurt_my <body part>] [broke_my  <bike part> ]
// ************************************************************************
void Parser::rode(void){

    cout << "rode"  << endl;

    if (nextToken == Rode_at) {
	nextToken = lexer.lex();
        location();
	if (nextToken == on) {
            nextToken = lexer.lex();
	    day_of_week();

            // Missing optoinal sections

	}
	else {
            success = false;
            cout << "Error in rode: expecting on";
        }
    }
    else {
        success = false;
	cout << "Error in rode: expecting Road_at";
    }
}

// ************************************************************************
//  <repair --> now_I_need_my <bike part> fixed
// ************************************************************************
void Parser::repair(void){
	cout << "repair"  << endl;

	if (nextToken == now_I_need_my) {
	     nextToken = lexer.lex();
		 bike_part();
	     if (nextToken == fixed) {
                nextToken = lexer.lex();
	     }
	     else{
                success = false;
		cout << "Error in repair: expecting fixed";
             }
	 }
	 else {
            success = false;
            cout << "Error in repair: expecting now_I_need_my";
         }
}

// ************************************************************************
//  <location> --> Willowdale | Fells | LDT | RM |  HP | LLF
// ************************************************************************
void Parser::location(void){
	cout << "location"  << endl;

	if (nextToken == Willowdale || nextToken == Fells || nextToken == LDT || nextToken == RM || nextToken == HP || nextToken == LLF)
            nextToken = lexer.lex();
	else {
            success = false;
            cout << "Error in location\n";
        }

}

// ************************************************************************
// <day_of_week>--> Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday
// ************************************************************************
void Parser::day_of_week(void){
	cout << "day of week"  << endl;
	if (nextToken == Monday || nextToken == Tuesday || nextToken == Wednesday || nextToken == Thursday || nextToken == Friday || nextToken == Saturday || nextToken == Sunday )
		nextToken = lexer.lex();
	else{
            success = false;
            cout << "Error in day of week\n";
        }
}
