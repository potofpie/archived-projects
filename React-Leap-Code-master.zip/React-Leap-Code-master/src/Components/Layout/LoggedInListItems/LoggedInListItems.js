import React, { Component } from 'react';
import AccountCircle from '@material-ui/icons/AccountCircle';
import InfoRounded from '@material-ui/icons/InfoRounded';
import HomeRounded from '@material-ui/icons/HomeRounded';
import ErrorRounded from '@material-ui/icons/ErrorRounded';
import PollRounded from '@material-ui/icons/PollRounded';
import FitnessCenterRounded from '@material-ui/icons/FitnessCenterRounded';
import RssFeedRounded from '@material-ui/icons/RssFeedRounded';
import SettingsRounded from '@material-ui/icons/SettingsRounded';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import List from '@material-ui/core/List';
import {Route, Link} from 'react-router-dom';


class LoggedOutListItems extends Component {

  iconSwitch(param) {
  switch(param) {
    case 0:
      return <HomeRounded/>;
    case 1:
      return <AccountCircle/>;
    case 2:
      return <PollRounded/>
    case 3:
      return <FitnessCenterRounded/>
    case 4:
      return <RssFeedRounded/>
    case 5:
      return <InfoRounded/>
    default:
      return <ErrorRounded color='secondary'/>;
    }
  }
  linkSwitch(param) {
    switch(param) {
      case 0:
        return '/home';
      case 1:
        return '/account';
      case 2:
        return '/leaderboard'
      case 3:
          return '/workout'
      case 4:
          return '/feed'
      case 5:
          return '/infomation';
      default:
        return '/404';
      }
  }

  render() {
    return (
      <div>
      <List>
        {['Home', 'Account', 'Leaderboard', 'Workout Session', 'News Feed', 'Infomation'].map((text, index) => (
          <ListItem button component={Link} to={this.linkSwitch(index)} key={text}  >
            <ListItemIcon>{this.iconSwitch(index)}</ListItemIcon>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
      </div>
    );
  }
}

export default LoggedOutListItems;
