//Okey make onClick function reload the <main> tag to the corriponeding button.
//use setState() and if statement in mains

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {Route, Link} from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import AccountCircle from '@material-ui/icons/AccountCircle';
import InfoRounded from '@material-ui/icons/InfoRounded';
import HomeRounded from '@material-ui/icons/HomeRounded';
import ErrorRounded from '@material-ui/icons/ErrorRounded';
import SettingsRounded from '@material-ui/icons/SettingsRounded';
import PollRounded from '@material-ui/icons/PollRounded';
import Button from '@material-ui/core/Button';
import Switch from '@material-ui/core/Switch';




const button = {
   margin: '10px'
};

const containerAppBarItems = {
    width: '100%',
    backgroundColor: 'pink',
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    flexDirection: 'row',
  }

class AppBarLoggedIn extends Component {
  render() {
    const { classes, theme, childern } = this.props;

    return (
            <div className={containerAppBarItems}>
              <Button variant="contained" component={Link} to={"/login"} className={button} size="small" color="primary">
                Logout
              </Button>
            </div>
    );
  }
}


export default AppBarLoggedIn;
