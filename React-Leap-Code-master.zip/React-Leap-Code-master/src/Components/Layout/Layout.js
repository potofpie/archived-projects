//Okey make onClick function reload the <main> tag to the corriponeding button.
//use setState() and if statement in mains

import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {Route, Link} from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import logo from '../../Resources/logo_transparent.png';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import AccountCircle from '@material-ui/icons/AccountCircle';
import InfoRounded from '@material-ui/icons/InfoRounded';
import HomeRounded from '@material-ui/icons/HomeRounded';
import ErrorRounded from '@material-ui/icons/ErrorRounded';
import SettingsRounded from '@material-ui/icons/SettingsRounded';
import PollRounded from '@material-ui/icons/PollRounded';
import Button from '@material-ui/core/Button';
import Switch from '@material-ui/core/Switch';
import LoggedOutListItems from './LoggedOutListItems/LoggedOutListItems'
import LoggedInListItems from './LoggedInListItems/LoggedInListItems'
import AppBarLoggedOut from './AppBarLoggedOut/AppBarLoggedOut'
import AppBarLoggedIn from './AppBarLoggedIn/AppBarLoggedIn'

const drawerWidth = 240;

const styles = theme => ({
  root: {
    display: 'flex',
  },
  logo:
  {
    height: '50px'
  },
  containerAppBarItems: {
    width: '100%',

    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    flexDirection: 'row',
  },
  button:
  {
     margin: '10px'
  },
  settingsButton:
  {
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginLeft: 12,
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing.unit * 7 + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing.unit * 9 + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing.unit * 3,
  },
});

class MiniDrawer extends React.Component {
  state = {
    open: false,
    content: 'IDK',
    loggedIn: false,
  };

  handleDrawerOpen = () => {
    this.setState({ open: true });
  };

  handleDrawerClose = () => {
    this.setState({ open: false });
  };

  onChangeSwitchListener = () => {
    this.setState({ loggedIn: !this.state.loggedIn });
    console.log("change");
  };

  testclick = (param) => {
      //not sure why but switching this from caseSwaitch to if else made this work better
      if( param === "Login"){
        console.log("Login Clicked");
        this.setState({ content: 'login' });
      } else if(param === "Info"){
        console.log("Info Clicked");
        this.setState({ content: 'info' });
      } else if(param === "Leaderboard"){
        console.log("Leaderboard Clicked");
        this.setState({ content: 'leaderboard' });
      } else{
        console.log("IDK Clicked");
        this.setState({ content: 'IDK' });
      }
  };
  iconSwitch(param) {
  switch(param) {
    case 0:
      return <HomeRounded/>;
    case 1:
      return <AccountCircle/>;
    case 2:
      return <PollRounded/>;
    default:
      return <ErrorRounded color='secondary'/>;
    }
  }
  linkSwitch(param) {
    console.log("linkSwitch");
  switch(param) {
    case 0:
      return '/';
    case 1:
      return '/login';
    case 2:
      return '/contactus';
    case 3:
      return '/leaderboard';
    default:
      return '/404';
    }
  }
  render() {
    const { classes, theme, childern } = this.props;

    return (
      <div className={classes.root}>
        <CssBaseline />
        <AppBar
          color='yellow'
          position="fixed"
          className={classNames(classes.appBar, {
            [classes.appBarShift]: this.state.open,
          })}
        >
        <div>
          
        </div >
          <Toolbar disableGutters={!this.state.open}>
            <IconButton
              color="inherit"
              aria-label="Open drawer"
              onClick={this.handleDrawerOpen}
              className={classNames(classes.menuButton, {
                [classes.hide]: this.state.open,
              })}
            >
              <MenuIcon />
            </IconButton>
            <img src={logo} className={classes.logo}></img>
            <Switch onChange={this.onChangeSwitchListener}/>
            {(this.state.loggedIn) ? <AppBarLoggedIn/> : <AppBarLoggedOut/>}
          </Toolbar>
        </AppBar>
        <Drawer
          variant="permanent"
          className={classNames(classes.drawer, {
            [classes.drawerOpen]: this.state.open,
            [classes.drawerClose]: !this.state.open,
          })}
          classes={{
            paper: classNames({
              [classes.drawerOpen]: this.state.open,
              [classes.drawerClose]: !this.state.open,
            }),
          }}
          open={this.state.open}
        >
          <div className={classes.toolbar}>
            <IconButton onClick={this.handleDrawerClose}>
              {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
            </IconButton>
          </div>
          <Divider />
          {(this.state.loggedIn) ? <LoggedInListItems/> : <LoggedOutListItems/>}
          <Divider />
        </Drawer>
        <main className={classes.content}>
          <div className={classes.toolbar} />
            {this.props.children}
        </main>
      </div>
    );
  }
}

MiniDrawer.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(MiniDrawer);
