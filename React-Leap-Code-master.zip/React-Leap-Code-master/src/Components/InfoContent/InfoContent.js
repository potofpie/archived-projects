import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

import Avatar from '../AvatarCard/AvatarCard';
import BobbyPic from '../../Resources/bobby_profile.jpg'
import DylanPic from '../../Resources/dylan_profile.jpg'

class InfoContent extends Component {
  render() {
    return (
      <div>
        <h1> Infomation  </h1>
        <div>Icons made by <a href="https://www.freepik.com/" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" 			    title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 			    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
        <br/>
        <Avatar name={'Bobby Christopher'} other={"Fucks"} phone={'559-360-5663'} email={"rec3college@gmail.com"} pic={BobbyPic}/>
        <Avatar name={'Dylan GeyBals'} other={"Shits"} phone={'000-911-0000'} email={"email@email.com"} pic={DylanPic}/>



      </div>
    );
  }
}

export default InfoContent;
