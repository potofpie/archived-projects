import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';


class HomeContent extends Component {
  render() {
    return (
      <div>
        <h1> Home  </h1>
      </div>
    );
  }
}

export default HomeContent;
