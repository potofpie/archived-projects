import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import pic from '../../Resources/bobby_profile.jpg'
import ErrorRounded from '@material-ui/icons/ErrorRounded';

const styles = {
  avatar: {
    margin: 10,
  },
  bigAvatar: {
    margin: 10,
    width: 200,
    height: 200,
  },
  card: {
    width: 275,
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    margin: '10px'

  },
  conText: {
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    textAlign: 'left',
    marginLeft: '25px',
    marginRight: '25px',
    marginBottom: '10px'
  },
  conAvatar: {
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'row',
    textAlign: 'center'
  },
};

function AvatarCard(props) {
  const { classes } = props;
  return (
      <Card className={classes.card}>
        <div className={classes.conAvatar}><Avatar alt="Remy Sharp" src={props.pic} className={classes.bigAvatar} /></div>
        <div className={classes.conText}>
          <div >{props.name}</div>
          <div><ErrorRounded/> {props.phone} </div>
          <div><ErrorRounded/> {props.email} </div>
          <div><ErrorRounded/>{props.other} </div>
        </div>

      </Card>
  );
}

AvatarCard.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(AvatarCard);
