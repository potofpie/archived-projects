import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import LoginCard from './LoginCard/LoginCard'

const divStyle = {

  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'row',
  textAlign: 'center'
};

class LoginContent extends Component {
  render() {
    return (
      <div style={divStyle}>

        <LoginCard> Login </LoginCard>

      </div>
    );
  }
}

export default LoginContent;
