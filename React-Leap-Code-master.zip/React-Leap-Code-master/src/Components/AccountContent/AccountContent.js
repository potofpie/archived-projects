import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';


class AccountContent extends Component {
  render() {
    return (
      <div>
        <h1> Account </h1>

      </div>
    );
  }
}

export default AccountContent;
