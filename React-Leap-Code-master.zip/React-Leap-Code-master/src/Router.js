import React, { Component } from 'react';
import logo from './Resources/logo.svg';
import Button from '@material-ui/core/Button';
import Layout from './Components/Layout/Layout';
import {BrowserRouter } from 'react-router-dom';
import {Route,} from 'react-router-dom';
import InfoContent from './Components/InfoContent/InfoContent'
import LeaderboardContent from './Components/LeaderboardContent/LeaderboardContent'
import LoginContent from './Components/LoginContent/LoginContent'
import NotFound from './Components/NotFound/NotFound'
import HomeContent from './Components/HomeContent/HomeContent'
import AccountContent from './Components/AccountContent/AccountContent'
import WorkoutContent from './Components/WorkoutContent/WorkoutContent'
import FeedContent from './Components/FeedContent/FeedContent'
import CreateAccountContent from './Components/CreateAccountContent/CreateAccountContent'

class Router extends Component {
  render() {

    return (
      <BrowserRouter>
        <Layout>
          <Route path="/home" exact strict render={
            () => {
              return (<HomeContent/>)
            }
          } />
          <Route path="/account" exact strict render={
            () => {
              return (<AccountContent/>)
            }
          } />
          <Route path="/workout" exact strict render={
            () => {
              return (<WorkoutContent/>)
            }
          } />
          <Route path="/feed" exact strict render={
            () => {
              return (<FeedContent/>)
            }
          } />
          <Route path="/infomation" exact strict render={
            () => {
              return (<InfoContent/>)
            }
          } />
          <Route path="/leaderboard" exact strict render={
            () => {
              return (<LeaderboardContent/>)
            }
          } />
          <Route path="/createaccount" exact strict render={
            () => {
              return (<CreateAccountContent/>)
            }
          } />
          <Route path="/login" exact strict render={
            () => {
              return (<LoginContent/>)
            }
          } />
          <Route path="/404" exact strict render={
            () => {
              return (<NotFound/>)
            }
          } />
        </Layout>
      </BrowserRouter>
    );
  }
}

export default Router;
