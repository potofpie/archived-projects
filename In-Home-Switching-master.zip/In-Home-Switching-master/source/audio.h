// TODO: Proper context stuff. Pretty hacky right now.

void audioHandlerLoop();