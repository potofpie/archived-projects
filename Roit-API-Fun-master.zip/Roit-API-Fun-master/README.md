# Roit API Fun

## Desciption
This was a program to test my ability to use the Riot API for Leauge of Legends.  When you change the username varible it will check if that specific user is in a match. It will then do a count down untill the match is over and print out the final time.
