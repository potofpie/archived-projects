import requests
import time

apiKey = ''

def getPlayerData(playerName):
    url = 'https://na1.api.riotgames.com/lol/summoner/v3/summoners/by-name/' + playerName + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    playerData =  jsonObject.json()
    return playerData

def inMatch(username):
    p = getPlayerData(username)
    if(0 == getCurrMatch(p['id'])):
        print p
        return 0
    else:
        return 1

def getCurrMatch(playerId):
    url = 'https://na1.api.riotgames.com/lol/spectator/v3/active-games/by-summoner/' + str(playerId) + '?api_key=' + apiKey
    jsonObject = requests.get(url)
    matchData =  jsonObject.json()
    valid = checkMatch(matchData)
    if(valid):
        return matchData
    else:
        return 0

def checkMatch(matchData):
    try:
        matchData['status']
        valid = 0
        return valid
    except:
        valid = 1
        return valid

def getPlayerGameSec(pId):
    realTime = int(time.time()*1000)
    if(0 != getCurrMatch(pId)):
        startTime = getCurrMatch(pId)['gameStartTime']
        currGameTime = int(realTime - startTime)
        return currGameTime / 1000

def getPlayerGameTimeStr(username):
    #t1 = time.time() #t1 and t2 are a timer for the program to print out the time of the game every 30 secs
    player = getPlayerData(username)
    secs = getPlayerGameSec(player['id'])
    minu = str(secs // 60)
    if( 10 > (secs % 60)):
        thing = str(minu) + ':0' + str(secs % 60)
    else:
        thing = str(minu) + ':' + str(secs % 60)
    return thing

def loopForPrintingTime(username):
    print getPlayerGameTimeStr(x)


def endOfGame(username):
    print username + 'game has ended'


####MAIN####
x = raw_input('Enter a username: ')
if(1 == inMatch(x)):
    print x + ' is in a game...'
    while(1):
        if(0 == inMatch(x)):
            endOfGame(x)
            break;
        else:
            loopForPrintingTime(x)
else:
    print x + ' is not in a game!'
