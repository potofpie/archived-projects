import time
import re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import pandas as pd

Email = []
ID = []
driver = webdriver.Firefox()
username = ''
password = ''
#sharknet^^


def regex(id):
    '''This was writen by Dylan Gebel'''
    save = re.compile(r'00(\d)3')
    matches = save.finditer(id)
    ret = ""
    for yee in matches:
        ret += yee.group(1)
    return ret

def grabAcc():
    global Email
    global ID
    global driver
    #Grab the element on the current page with class ms-listviewtable
    tableCon = driver.find_element(By.CLASS_NAME, 'ms-listviewtable')
    #find the child that has the tag body
    table = tableCon.find_element(By.XPATH, "tbody")
    #Sleep to wait for the webpage to load
    time.sleep(1)
    #Looks for all elements with the tag tr. This will be all the student on this page once we get
    studentList = table.find_elements_by_tag_name("tr")
    #This is here because the first 12 things garbage info and this was the fastest way to deal with it
    for i in range(12):
        studentList.pop(0)

    for j in studentList:
        #Grab the element in tr with class ms-vb-title
        importantStuff = j.find_element(By.CLASS_NAME, 'ms-vb-title')
        #Grab the element in tr with class ms-vb-title
        theDiv = importantStuff.find_element(By.XPATH, "div")
        ID.append('P' + regex(theDiv.get_attribute('id')))
        a = j.find_element_by_xpath('td[contains(text(), "@landmark.edu")]')
        Email.append(a.get_attribute('innerHTML'))




def main():
    global driver
    global Email
    global ID
    #Logs in to sharknet
    driver.get("https://" + username +":" + password + "@sharknet.landmark.edu/")
    #Find People / Places / Hours in the current page and click it
    driver.find_element(By.PARTIAL_LINK_TEXT, 'People / Places / Hours').click()
    #Find Student Directory in the current page and click it
    driver.find_element(By.PARTIAL_LINK_TEXT, 'Student Directory').click()
    #Sleep to wait for the webpage to load
    time.sleep(1)
    #Gets the page number and cuts off the first 4 character to get the number of pages

    grabAcc()
    #The person who made this site changed the name the button for pages 2-11 so I have to click on this on for the first page
    driver.find_element_by_xpath("/html/body/form/div[8]/div/div[3]/div[2]/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td/div/div[1]/table[2]/tbody/tr[3]/td/table/tbody/tr/td[2]/a").click()
    time.sleep(1)
    #this loops through the pages and grabs all the info
    for i in range(11):
        grabAcc()
        driver.find_element_by_xpath("/html/body/form/div[8]/div/div[3]/div[2]/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td/div/div[1]/table[2]/tbody/tr[3]/td/table/tbody/tr/td[3]/a").click()
        time.sleep(1)
    grabAcc()

    time.sleep(1)
    driver.close()

    #Creates dic with Email and ID
    df_students = pd.DataFrame({'Email':Email,'ID':ID})
    #makes writer with name studentList
    writer = pd.ExcelWriter('studentList.xlsx')
    df_students.to_excel(writer,index=False)
    writer.save()



if __name__ == "__main__":
    main()
