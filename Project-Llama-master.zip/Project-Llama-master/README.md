# Project L.L.A.M.A.
Locking Landmark Against Malicious Attacks

## Code written by:
- Dylan Gebel
- Dennis Champagne
- Bobby Christopher

## Description: <br/>
We noticed that while using the student and faculty pictorial directory there was a flaw.  The names of the pictures were the student's ID numbers which are also the default passwords for all accounts.  We proceeded to see how many students and faculty members did not change their passwords from thier default password.  Because there were systems put in place to prevent web scraping, this is where our time was primary spent.  We discovered that 78% of student and 15% of teacher accounts were compromised.

## Language:
- Python

## 3rd Party Libraries:
- Selenium
- Pandas 
- O365

## Files:

| logmein.py |
- This script tests if your account is compromised by attempting to log into the account.

| scrapStudents.py |
- This script uses Selenium to simulate a browser to scrape all the necessary student information to compromise the accounts. 





