import time

def bSearch():
    time.sleep(5)

def dSearch():
    time.sleep(9)
