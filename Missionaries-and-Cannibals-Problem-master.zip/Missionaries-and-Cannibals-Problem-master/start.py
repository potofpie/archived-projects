import pygame

def boat(x, y):
        gameDisplay.blit( boat, (x,y))

def myQuit():
    print("Bye")

#def boat():
 #   gameDisplay.blit(boat, (display_width*0.25, display_height*0.5))


def myInit():


        #stuff
        display_width = 800
        display_height = 600
        black = (0,0,0)
        white = (255,255,255)
        red = (255,0,0)
        green = (0,255,0)
        blue = (0,0,255)

        #monster = pygame.image.load("CthulhuHD.png")
        #person = pygame.image.load("CJeff_Luke_SNU.png")
        boat = pygame.image.load("rsz_junk_boat.png")

        gameDisplay = pygame.display.set_mode((display_width, display_height))
        pygame.display.set_caption('State Space Search')
        clock = pygame.time.Clock()
        crashed = False
        gameDisplay.blit(boat, (display_width*0.25, display_height*0.5))

        while not crashed:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    crashed = True

                print(event)
                pygame.display.update()

                clock.tick(60)
        myQuit()
        pygame.quit()
        quit()











pygame.init()
myInit()
