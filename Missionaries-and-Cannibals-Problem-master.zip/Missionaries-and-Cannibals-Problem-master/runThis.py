f = open("info.txt", "w")
stack = []
import sys
import x

def printStack():
    print(" ")
'''
    for layer in stack:
        print(layer[0])
        [left, right, i] = layer[1]
        print("Layer|: " + str(i))
        print("Left|: M:" + str(left[0]) + " C: " + str(left[1]))
        print("Right|: M:" + str(right[0]) + " C: " + str(right[1]))
'''

def initDepth(*args):
    x.dSearch()
    left = [3,3]
    right = [0,0]
    root = [left, right, 0]
    pickState(root)

def initBredth(*args):
    left = [3,3]
    right = [0,0]
    root = [left, right, 0]
    x.bSearch()
    pickState(root)


def checkState(state):
    [left, right, i] = state
    f.write("-----------------------------\n")
    f.write("Layer|: " + str(i) + "\n")
    f.write("Left|: M:" + str(left[0]) + " C: " + str(left[1]) + "\n")
    f.write("Right|: M:" + str(right[0]) + " C: " + str(right[1]) + "\n")
    if(right[0] == 3 and right[1] == 3):
        print("Goal State. Check info.txt for state space with goal state.")
        printStack()
        exit()
    if(left[0] >= left[1] or right[0] >= right[1]):
        if(state[2] < 15):
            return True
    #print("Lose State" + "\n")
    if(state[2] < 15):
        f.write("Lose State\n")
    else:
        f.write("To Large\n")
    return False

def moveTwoCanToRight(state):
    [left, right, i] = state
    if(left[1] < 2):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveTwoCanToRight" + "\n")
    left[1] = left[1] - 2
    right[1] = right[1] + 2
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveTwoCanToLeft(state):
    [left, right, i] = state
    if(right[1] < 2):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveTwoCanToLeft" + "\n")
    right[1] = right[1] - 2
    left[1] = left[1] + 2
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveTwoMisToRight(state):
    [left, right, i]  = state
    if(left[0] < 2):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveTwoMisToRight" + "\n")
    left[0] = left[0] - 2
    right[0] = right[0] + 2
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])


def moveTwoMisToLeft(state):
    [left, right, i]  = state
    if(right[0] < 2):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveTwoMisToLeft" + "\n")
    right[0] = right[0] - 2
    left[0] = left[0] + 2
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveCanMisToRight(state):
    [left, right, i]  = state
    if(left[0] < 1):
        return
    if(left[1] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveCanMisToRight" + "\n")
    left[0] = left[0] - 1
    left[1] = left[1] - 1
    right[0] = right[0] + 1
    right[1] = right[1] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveCanMisToLeft(state):
    [left, right, i]  = state
    if(right[0] < 1):
        return
    if(right[1] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveCanMisToLeft" + "\n")
    right[0] = right[0] - 1
    right[1] = right[1] - 1
    left[0] = left[0] + 1
    left[1] = left[1] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveOneCanToRight(state):
    [left, right, i] = state
    if(left[1] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveOneCanToRight" + "\n")
    left[1] = left[1] - 1
    right[1] = right[1] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveOneCanToLeft(state):
    [left, right, i] = state
    if(right[1] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveOneCanToLeft" + "\n")
    right[1] = right[1] - 1
    left[1] = left[1] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveOneMisToRight(state):
    [left, right, i]  = state
    if(left[0] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveOneMisToRight" + "\n")
    left[0] = left[0] - 1
    right[0] = right[0] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])

def moveOneMisToLeft(state):
    [left, right, i]  = state
    if(right[0] < 1):
        return
    f.write("-----------------------------" + "\n")
    f.write("moveOneMisToLeft" + "\n")
    right[0] = right[0] - 1
    left[0] = left[0] + 1
    if(checkState([left,right,i]) == False):
        return
    pickState([left,right, i + 1])



def pickState(state):
    stack.append(["moveTwoCanToRight", state])
    moveTwoCanToRight(state)
    stack.pop(len(stack)-1)

    stack.append(["moveTwoCanToLeft", state])
    moveTwoCanToLeft(state)
    stack.pop(len(stack)-1)

    stack.append(["moveTwoMisToRight", state])
    moveTwoMisToRight(state)
    stack.pop(len(stack)-1)

    stack.append(["moveTwoMisToLeft", state])
    moveTwoMisToLeft(state)
    stack.pop(len(stack)-1)

    stack.append(["moveCanMisToRight", state])
    moveCanMisToRight(state)
    stack.pop(len(stack)-1)

    stack.append(["moveCanMisToLeft", state])
    moveCanMisToLeft(state)
    stack.pop(len(stack)-1)

    stack.append(["moveOneCanToRight", state])
    moveOneCanToRight(state)
    stack.pop(len(stack)-1)

    stack.append(["moveOneCanToLeft", state])
    moveOneCanToLeft(state)
    stack.pop(len(stack)-1)

    stack.append(["moveOneMisToRight", state])
    moveOneMisToRight(state)
    stack.pop(len(stack)-1)

    stack.append(["moveOneMisToLeft", state])
    moveOneMisToLeft(state)
    stack.pop(len(stack)-1)

if(sys.argv[1] == "depth"):
    initDepth(15, 10)
if(sys.argv[1] == "bredth"):
    initBredth(10, 15)
