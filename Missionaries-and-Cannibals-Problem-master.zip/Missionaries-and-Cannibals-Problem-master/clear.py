f = open("info.txt", "w")
f.write("\n")
