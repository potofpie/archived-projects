import java.awt.image.*;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.*;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.imageio.*;
import java.io.*;
import java.util.*;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.imageio.*;
import java.util.Random;
import java.io.*;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.swing.*;

public class LineDrawer extends JPanel{
  Graphics2D g2d;
  BufferedImage img=null;
  static int slope, b;
  int cursorX, cursorY;
  static int points[] = new int[4];

    public LineDrawer(int[] args) {
      super();
      points = args;
    }
    public static void calcForm(){
      slope = (points[0]-points[2]) / (points[1]-points[3]);
      b = points[1] - (points[0]*slope);
    }
    public static int calcPoint(int x){
      int y = (slope*x)+b;
      return y;
    }
    public synchronized void paintComponent(Graphics g)
    {
      Color color = new Color(0.0f, 0.0f, 0.0f);
      calcForm();
      g2d = (Graphics2D) g;
      cursorX = points[0];
      while(points[2] != cursorX)
      {
          cursorY = calcPoint(cursorX);
          img.setRGB(cursorX,cursorY,color.getRGB());
          int lookAhead = (calcPoint(cursorX + 1)) -1;
          int dis = (calcPoint(cursorX + 1) - cursorY) - 1;
          while(dis != 0)
          {
            img.setRGB(cursorX,lookAhead,color.getRGB());
            lookAhead--;
            dis--;
          }
          while(dis != 0)
          {
            img.setRGB(cursorX,lookAhead,color.getRGB());
            lookAhead--;
            dis--;
          }
          System.out.printf("x = " + cursorY + " | x++ = " + calcPoint(cursorX + 1) + "\n");
          cursorX++;
      }
        g2d.drawImage(img, null, 0, 0);

        try {
            File outputfile = new File("saved.png");
            ImageIO.write(img, "png", outputfile);
        } catch (IOException e) {
          System.out.println("Something went wrong with saving the file");
        }
    }
}
