import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class MGui6 {
	public static void main(String[] args) {
    int[] points = {Integer.parseInt(args[0]), Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3])};
		System.out.println(points[0] + " " + points[1] + " " +  points[2] + " "  + points[3]);
		JFrame bframe=new Gui6(points);
		bframe.setLocation(32,32);
                bframe.setSize(500,500);
		bframe.setVisible(true);
		bframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
