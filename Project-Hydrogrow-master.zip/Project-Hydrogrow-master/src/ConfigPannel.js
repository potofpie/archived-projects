import React from 'react';
import { Jumbotron, Button } from 'reactstrap';
import './Pannel.css';
import ToggleButton from './ToggleButton'
import { Row, Col } from 'reactstrap';
import TimePicker from 'react-time-picker'
import InstantToggle from './InstantToggle'
import SceduledToggle from './SceduledToggle'
import Center from 'react-center';



const ConfigPannel = (props) => {
  return (
    <div className='pannel'> 
      <Jumbotron>
      <h1>Config Panel</h1>
      <hr/>
      <br></br>
      <Center>
        <Row> 
          <InstantToggle></InstantToggle>
          <div className='vl'></div>
          <SceduledToggle></SceduledToggle>
        </Row>
      </Center>

      </Jumbotron>
    </div>
  );
};

export default ConfigPannel;