import React from 'react';
import { Jumbotron, Button } from 'reactstrap';
import './Pannel.css';
import ToggleButton from './ToggleButton'
import { Row, Col } from 'reactstrap';
import TimePicker from 'react-time-picker'


const InstantToggle= (props) => {
  return (
    <div> 
          <Col >
          <br></br>
          <h4>Instant Toggle</h4>
            <br></br>
            <ToggleButton text='Pump'></ToggleButton>
            <br></br>
            <br></br>
            <ToggleButton text='Bulb'></ToggleButton>
          </Col>
    </div>
  );
};

export default InstantToggle;