import React, { Component } from 'react';
import { Button } from 'reactstrap';
import './App.css';
import DropDown from './DropDown.js';
import ConfigPannel from './ConfigPannel.js';
import { Row } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  render() {
    return (
      <div className="padding">
        <hr/>
        <h1>HydroGrow</h1>
        <p> The automated hydroponic farm! </p>
        <hr/>
      
        

      </div>
    );
  }
}

export default App;
