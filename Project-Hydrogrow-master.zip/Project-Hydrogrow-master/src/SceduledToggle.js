import React from 'react';
import { Jumbotron, Button } from 'reactstrap';
import './Pannel.css';
import ToggleButton from './ToggleButton'
import { Row, Col } from 'reactstrap';
import TimePicker from 'react-time-picker'


const InstantToggle= (props) => {
  return (
    <div> 
                 <Col>
          <br></br>
          <h4>Scheduled Toggle</h4>
          <Row>
              <div ></div>
              <Col xs="2">
                
                <br></br>
                <h5>Pump</h5>
                <br></br>
                <br></br>
                <h5>Bulb</h5>
              </Col>
              <Col xs="4">
                
                <br></br>
                <TimePicker></TimePicker>
                <br></br>
                <br></br>
                <br></br>
                <TimePicker></TimePicker>
              </Col >
              <Col xs="2">
                
                <br></br>
                <h5>To</h5>
                <br></br>
                <br></br>
                <h5>To</h5>
              </Col>
              <Col xs="4">
                
                <br></br>
                <TimePicker></TimePicker>
                <br></br>
                <br></br>
                <br></br>
                <TimePicker></TimePicker>
              </Col>
              </Row>
              </Col>
    </div>
  );
};

export default InstantToggle;