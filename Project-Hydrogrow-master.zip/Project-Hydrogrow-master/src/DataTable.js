import React from 'react';
import { Table } from 'reactstrap';

export default class DataTable extends React.Component {
  render() {
    return (
      <Table>
        <tbody>
          <tr>
            <th scope="row">Water Temperature</th>
            <td>*data*</td>
          </tr>
          <tr>
            <th scope="row">Water Level</th>
            <td>*data*</td>
          </tr>
          <tr>
            <th scope="row">PHP</th>
            <td>*data*</td>
          </tr>
          <tr>
            <th scope="row">PHP</th>
            <td>*data*</td>
          </tr>
        </tbody>
      </Table>
    );
  }
}
