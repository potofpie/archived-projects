import React, { Component } from 'react';
import './App.css';
import Header from './Header.js';
import ConfigPannel from './ConfigPannel.js';
import MainPannel from './MainPannel.js';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header/>
        <MainPannel></MainPannel>
        <ConfigPannel></ConfigPannel>
      </div>
    );
  }
}

export default App;
