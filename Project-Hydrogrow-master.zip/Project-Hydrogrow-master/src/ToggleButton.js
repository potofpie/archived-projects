import React, { Component } from 'react';
import { Button, ButtonGroup, Row } from 'reactstrap';
import './Pannel.css';
import TimePicker from 'react-time-picker'
class ToggleButton extends Component {
  constructor (props) {
    super(props);

    this.state = { cSelected: [] };

    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);
    this.onCheckboxBtnClick = this.onCheckboxBtnClick.bind(this);
  }

  onRadioBtnClick(rSelected) {
    this.setState({ rSelected });
  }

  onCheckboxBtnClick(selected) {
    const index = this.state.cSelected.indexOf(selected);
    if (index < 0) {
      this.state.cSelected.push(selected);
    } else {
      this.state.cSelected.splice(index, 1);
    }
    this.setState({ cSelected: [...this.state.cSelected] });
  }

  render() {
    return (
      <div>
        <Row>
        <p>*Debug* {this.state.rSelected}</p>
            <ButtonGroup className='padding'>
              <Button color="success" onClick={() => this.onRadioBtnClick(1)} active={this.state.rSelected === 1}>ON</Button>
              <Button color="danger" onClick={() => this.onRadioBtnClick(2)} active={this.state.rSelected === 2}>OFF</Button>
            </ButtonGroup>
            <h5 className='padding' > { this.props.text } </h5>
        </Row>
      </div>
    );
  }
}

export default ToggleButton;