import React from 'react';
import { Jumbotron, Button } from 'reactstrap';
import './Pannel.css';
import ToggleButton from './ToggleButton'
import DataTable from './DataTable'
import { Row, Col } from 'reactstrap';
import TimePicker from 'react-time-picker'
import InstantToggle from './InstantToggle'
import SceduledToggle from './SceduledToggle'



const ConfigPannel = (props) => {
  return (
    <div className='pannel'> 
      <Jumbotron>
      <h1>Main Panel</h1>
      <hr/>
      <Row>
      <div className='vl'></div>
        <div className='center '>
          <DataTable></DataTable>
        </div>
      
      </Row>
      </Jumbotron>
    </div>
  );
};

export default ConfigPannel;