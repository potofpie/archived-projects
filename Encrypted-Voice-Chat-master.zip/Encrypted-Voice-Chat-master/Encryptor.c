#include <openssl/rsa.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define KEY_SIZE 2048/8

typedef struct ThingsOfGreatImportance {
   char readyData[KEY_SIZE];
   int len;
} togi;


RSA* getPubKey(RSA *kp)//unused function
{
    BIO *tmpBio = BIO_new(BIO_s_mem());
    PEM_write_bio_RSA_PUBKEY(tmpBio, kp);
    if(tmpBio == NULL)
            return NULL;

    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
    EVP_PKEY *tmpPkey = (EVP_PKEY *) PEM_read_bio_PUBKEY(tmpBio, NULL, NULL, NULL);
    #pragma GCC diagnostic pop
    if(tmpPkey == NULL)
        return NULL;

    RSA *pubRsa = EVP_PKEY_get1_RSA(tmpPkey);
    if(pubRsa == NULL)
        return NULL;

    return pubRsa;
}

char* getPubKeyStr(RSA *kp)
{
    if(kp==NULL)return NULL;
    BIO *tmpBio = BIO_new(BIO_s_mem());
    PEM_write_bio_RSA_PUBKEY(tmpBio, kp);
        if(tmpBio == NULL)
            return NULL;

    size_t pub_len = BIO_pending(tmpBio);
    char *pub_key = malloc(pub_len + 1);
    BIO_read(tmpBio, pub_key, pub_len);

    pub_key[pub_len] = '\0';

    return pub_key;
}

RSA* getPubKeyRSA(char *keyAsStr)
{
    if(keyAsStr==NULL)return NULL;
    char *buf=strdup(keyAsStr);
    BIO *tmpBio = BIO_new_mem_buf(buf,strlen(buf));
    if(tmpBio == NULL)
        return NULL;

    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
    EVP_PKEY *tmpPkey = (EVP_PKEY *) PEM_read_bio_PUBKEY(tmpBio, NULL, NULL, NULL);
    if(tmpPkey==NULL)
        ERR_print_errors_fp(stdout);
    #pragma GCC diagnostic pop
    if(tmpPkey == NULL)
        return NULL;
    RSA *pubRsa = EVP_PKEY_get1_RSA(tmpPkey);
    if(pubRsa == NULL)
        return NULL;

    return pubRsa;
}

RSA* getKeyPair()
{
    return RSA_generate_key(2048, 3, NULL, NULL);//generates keys
}
togi* encryptData(char* data, RSA *key,int datasize)
{
    if(key==NULL)return NULL;
    int encrypt_len;
    char *encrypt = malloc(RSA_size(key));
    memset(encrypt,0,RSA_size(key));
    char *err = malloc(130);
    //char *data = "bob";
    togi *t=malloc(sizeof(togi));
    if((encrypt_len = RSA_public_encrypt(datasize, (unsigned char*)data, (unsigned char*)encrypt, key, RSA_PKCS1_OAEP_PADDING)) == -1)
    {
        ERR_load_crypto_strings();
        ERR_error_string(ERR_get_error(), err);
        fprintf(stderr, "Error encrypting message: %s\n", err);
        //exit(1);
    }
    //printf("encrypt_len: %d\nencrypt_strlen: %d\n\n", encrypt_len,strlen(encrypt));
    memcpy(t->readyData, encrypt,encrypt_len);
    t->len = encrypt_len;
    return t;
}

char* decryptData(char* data, RSA *key, int encrypt_len)
{
    char *decrypt = malloc(KEY_SIZE+1);
    memset(decrypt,0,KEY_SIZE+1);
    char *err = malloc(130);
    memset(err,0,130);
    //printf("RSA_size: %d\nencrypt_len: %d\n\n", RSA_size(key),encrypt_len);
    if(RSA_private_decrypt(encrypt_len, (unsigned char*)data, (unsigned char*)decrypt, key, RSA_PKCS1_OAEP_PADDING) == -1)
	{

        ERR_load_crypto_strings();
        ERR_error_string(ERR_get_error(), err);
        fprintf(stderr, "Error decrypting message: %s\n", err);
        //exit(2);
    }
    return decrypt;
}

/*
typedef struct message
{
    int SID;
    int MID;
    struct timeval TSP;
    char MSG[64];
}Msg;

int main(int argc,char* argv[])
{
    char *buf=malloc(4096);
    memset(buf,0,4096);
    Msg *m=malloc(sizeof(Msg));
    memset(m,0,sizeof(Msg));
    char *bob="abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz\0";
    strcpy(m->MSG,bob);
    memcpy(buf,m,sizeof(Msg));
    RSA *keypair = getKeyPair();
    char *tmp=getPubKeyStr(keypair);
    printf("Key: %ld\n%s\n\n",strlen(tmp),tmp);
    RSA *pubKey=getPubKeyRSA(tmp);

    printf("%s\n",m->MSG);
    togi *x = encryptData(buf,pubKey,sizeof(Msg));
    char *newMsg = decryptData(x->readyData, keypair, x->len);
    memcpy(m,newMsg,sizeof(Msg));
    printf("%s\n",m->MSG);
}
*/
