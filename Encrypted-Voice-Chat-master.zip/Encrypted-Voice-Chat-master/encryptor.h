#include <openssl/rsa.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef BOBBY_ENCRYPT
#define BOBBY_ENCRYPT
#define KEY_SIZE 2048/8

typedef struct ThingsOfGreatImportance
{
   char readyData[KEY_SIZE];
   int len;
} togi;


RSA* getPubKey(RSA *kp);

char* getPubKeyStr(RSA *kp);

RSA* getPubKeyRSA(char *keyAsStr);

RSA* getKeyPair();

togi* encryptData(char* data, RSA *key,int datasize);

char* decryptData(char* data, RSA *key, int encrypt_len);

#endif
