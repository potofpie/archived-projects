#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>

#ifndef DC_IPC
#define DC_IPC

void P(sem_t *sem);

void V(sem_t *sem);

/**
make a semaphore. pshared is 0 for a semaphore shared between threads, and 1 for a semaphore shared between processes.
*/
sem_t *mkSem(int pshared,unsigned int value);

/**
get or create a shared memory segment. id is the ID for the segment. sz is the size of the data structure, and flags are the flags you want to pass to shmget. use 0 for default.
*/
void *initshm(key_t id,size_t sz,int flags);

/**
make a TCP server socket and wait for a connection.
*/
int waitForConnection(int port);

/**
make a TCP client connection to IP using PORT.
*/
int makeSocket(char *ip,int port);

#endif
