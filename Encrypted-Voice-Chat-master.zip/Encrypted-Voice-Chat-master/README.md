# Encrypted Voice Chat

I am in the process of converting two old projects into one. I have previously made a mock banking system where I wrote an  encryption header file for this project. I have also made a homebrew skype like program. I now intend to marry the two and encrypt voice calls. 
