#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <semaphore.h>


void P(sem_t *sem)
{
    sem_wait(sem);
}

void V(sem_t *sem)
{
    sem_post(sem);
}

/**
make a semaphore. pshared is 0 for a semaphore shared between threads, and 1 for a semaphore shared between processes.
*/
sem_t *mkSem(int pshared,unsigned int value)
{
    sem_t *sem;
    if((sem_t *)-1==(sem=malloc(sizeof(sem_t))))
    {
        printf("malloc failed, errno = %d   %s\n",errno,strerror(errno));
		printf("pshared = %d,\tvalue = %u,\n",pshared,value);
    }
    if(-1==sem_init(sem,pshared,value))
    {
        printf("sem_init failed, errno = %d   %s\n",errno,strerror(errno));
		printf("pshared = %d,\tvalue = %u,\n",pshared,value);
    }
    return sem;
}

/**
get or create a shared memory segment. id is the ID for the segment. sz is the size of the data structure, and flags are the flags you want to pass to shmget. use 0 for default.
*/
void *initshm(key_t id,size_t sz,int flags) 
{
    void *ptr;
    int shmid;
	if((shmid=shmget(id,sz,IPC_CREAT|flags))==-1)
	{
		printf("shmget failed, errno = %d   %s\n",errno,strerror(errno));
		printf("id = %d,\tsize = %lu,\tflags = %d\n",id,sz,flags);
	}
	if((ptr=(void *)shmat(shmid,0,0))==(void *)-1)
	{
		printf("shmat failed, errno = %d   %s\n",errno,strerror(errno));
		printf("id = %d,\tsize = %lu,\tflags = %d\n",id,sz,flags);
	}
	return ptr;
}

/**
make a TCP server socket and wait for a connection.
*/
int waitForConnection(int port)
{
    int lfd=0;
    int cfd=0;
    struct sockaddr_in serv_addr;
    lfd=socket(AF_INET,SOCK_STREAM,0); //tcp
    memset(&serv_addr,0,sizeof(serv_addr));

    serv_addr.sin_family=AF_INET;
    serv_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    serv_addr.sin_port=htons(port);

    if(bind(lfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
    {
        printf("socket failed to bind.\n");
        exit(1);
    }
    listen(lfd,10);
    return(cfd=accept(lfd,(struct sockaddr*)NULL,NULL));
}

/**
make a TCP client connection to IP using PORT.
*/
int makeSocket(char *ip,int port)
{
    int fd;
    struct sockaddr_in dest;
    fd=socket(AF_INET,SOCK_STREAM,0); //tcp
    memset(&dest,0,sizeof(dest));
    dest.sin_family=AF_INET;
    dest.sin_port=htons(port);
    int n=inet_aton(ip,&(dest.sin_addr));
    if(!n)
    {
        printf("Invalid address. %d\n",n);
        printf("IP: %s\n",ip);
        printf("dest->sin_fami: %hd\n",dest.sin_family);
        printf("dest->sin_port: %hu\n",dest.sin_port);
        printf("dest->sin_addr: %u\n",dest.sin_addr.s_addr);
    }

    if(n=connect(fd,(struct sockaddr*)&dest,sizeof(dest))<0)
    {
        printf("Connection error %d: %s\n",errno,strerror(errno));
        exit(1);
    }
    printf("connect: %d\n",n);
    printf("fd: %d\n",fd);
    return(fd);
}
